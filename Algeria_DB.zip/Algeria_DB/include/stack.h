#ifndef STACK_H
#define STACK_H

#include <stdbool.h>
#include "types.h"

// Stack operations
TStack* createStackNode(const char *name, const char *definition, Date dob, Date dod);
void push(TStack **top, const char *name, const char *definition, Date dob, Date dod);
TStack* pop(TStack **top);
TStack* peek(TStack *top);
bool isStackEmpty(TStack *top);
int stackSize(TStack *top);
void displayStack(TStack *top);
void clearStack(TStack **top);
void reverseStack(TStack **top);
void sortStack(TStack **top);
TStack* mergeStacks(TStack *stack1, TStack *stack2);
void splitStack(TStack *source, TStack **stack1, TStack **stack2);
TStack* copyStack(TStack *original);
void updateStack(TStack *top, const char *oldName, const char *newName, const char *newDef);
TStack* searchStack(TStack *top, const char *name);
void convertStackToQueue(TStack *stack, TQueue *queue);
void convertQueueToStack(TQueue *queue, TStack **stack);
int countStackNodes(TStack *top);
TStack* findMiddleStack(TStack *top);
bool isStackPalindrome(TStack *top);
void removeStackDuplicates(TStack *top);
TStack* rotateStack(TStack *top, int k);
void bubbleSortStack(TStack *top);
void selectionSortStack(TStack *top);
void insertionSortStack(TStack **top);
void mergeSortStack(TStack **top);
void quickSortStack(TStack **top);
TStack* partitionStack(TStack *head, TStack *end, TStack **newHead, TStack **newEnd);
void quickSortStackRec(TStack **head, TStack *end);

// Stack operations for historical data - Original
void pushPersonality(TStack **top, const char *name, const char *definition, Date dob, Date dod);
TStack* popPersonality(TStack **top);
void displayPersonalitiesStack(TStack *top);
TStack* searchPersonalityStack(TStack *top, const char *name);
void updatePersonalityStack(TStack *top, const char *oldName, const char *newName, const char *newDef);
void saveStackToFile(TStack *top, const char *filename);
TStack* loadStackFromFile(const char *filename);

// Missing functions from screenshots - Module 3: Stacks
TStack* toStack(TList *merged);
TStack* getInfoPersonality(TStack *stk, char *name);
TStack* sortNameStack(TStack *s);
TStack* deleteName(TStack *stk, char *name);
TStack* updateStack_v2(TStack *stk, char *name, char *def, char *DoB, char *DoD);
TQueue* stackToQueue(TStack *stk);
TList* stackToList(TStack *stk);
TStack* addNameStack(TStack *stk, char *name, char *definition, char *DoB, char *DoD);
TStack* definitionStack(TStack *stk);
TStack* pronunciationStack(TStack *stk);
char* getSmallest(TStack *stk);
void continuousSearch(TStack *stk, const char *query);
bool isPersonalityKilled(char *word);
TStack* recRevStack(TStack *stk);

#endif /* STACK_H */
