#ifndef BST_H
#define BST_H

#include <stdbool.h>
#include <stdio.h>
#include "types.h"
// BST operations
TTree* createBSTNode(const char *name, const char *definition, Date dob, Date dod);
TTree* insertBST(TTree *root, const char *name, const char *definition, Date dob, Date dod);
TTree* deleteBSTNode(TTree *root, const char *name);
TTree* searchBST(TTree *root, const char *name);
void inorderTraversal(TTree *root);
void preorderTraversal(TTree *root);
void postorderTraversal(TTree *root);
void levelOrderTraversal(TTree *root);
int treeHeight(TTree *root);
int countBSTNodes(TTree *root);
int countLeafNodes(TTree *root);
int countInternalNodes(TTree *root);
TTree* findMin(TTree *root);
TTree* findMax(TTree *root);
TTree* findLCA(TTree *root, const char *name1, const char *name2);
bool isBST(TTree *root);
bool isBalanced(TTree *root);
TTree* mirrorBST(TTree *root);
TTree* convertBSTToDLL(TTree *root);
TTree* mergeBSTs(TTree *root1, TTree *root2);
void printBST(TTree *root, int space);
void destroyBST(TTree *root);

// BST operations for historical data
TTree* insertPersonalityBST(TTree *root, const char *name, const char *definition, Date dob, Date dod);
TTree* deletePersonalityBST(TTree *root, const char *name);
TTree* searchPersonalityBST(TTree *root, const char *name);
void displayPersonalitiesBST(TTree *root);
TTree* findPersonalityByYear(TTree *root, int year);
TTree* findPersonalitiesInRange(TTree *root, int startYear, int endYear);
void updatePersonalityBST(TTree *root, const char *name, const char *newName, const char *newDef);
void saveBSTToFile(TTree *root, const char *filename);
TTree* loadBSTFromFile(const char *filename);
int countNodesRange(TTree *tr, int l, int h);
TTree* convertListToBST(TList *head);
TList* convertBSTToList(TTree *root);
void fillBST(TTree *root, TList **head);
TTree* buildBalancedBST(TList *head);
bool isCompleteBST(TTree *root);
bool isFullBST(TTree *root);
TTree* deleteNodeRange(TTree *root, int startYear, int endYear);
TTree* findSuccessor(TTree *root, const char *name);
TTree* findPredecessor(TTree *root, const char *name);
void printAncestors(TTree *root, const char *name);
void printDescendants(TTree *root, const char *name);
int getDepth(TTree *root, const char *name);
int getLevel(TTree *root, const char *name);
bool areSiblings(TTree *root, const char *name1, const char *name2);
bool areCousins(TTree *root, const char *name1, const char *name2);

// Missing functions from screenshots - Module 4: BST
TTree* toTree(TStack *stk);
TTree* fillTree(FILE *f);
TTree* getInfoNameTree(TTree *tr, char *name);
TStack* addNameBST(TTree *tr, char *name, char *DoB, char *DoD);
TTree* deleteNameBST(TTree *tr, char *name);
TTree* updateNameBST(TTree *tr, char *name, char *s, char *DoB, char *DoD);
TTree* traversalBSTinOrder(TTree *tr);
TTree* traversalBSTpreOrder(TTree *tr);
TTree* traversalBSTpostOrder(TTree *tr);
void heightSizeBST(TTree *tr);
TTree* lowestCommonAncestor(TTree *tr, char *word1, char *word2);
TTree* inOrderSuccessor(TTree *tr, char *word);
TTree* BSTMirror(TTree *tr);
bool isBalancedBST(TTree *tr);
TTree* BTSMerge(TTree *tr1, TTree *tr2);

#endif /* BST_H */
