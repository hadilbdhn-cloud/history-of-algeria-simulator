#ifndef TYPES_H
#define TYPES_H

#include <stdbool.h>

typedef struct {
    int day;
    int month;
    int year;
} Date;

typedef struct TList {
    char name[100];
    char definition[500];
    Date dob;                /* Date of Birth */
    Date dod;                /* Date of Death */
    struct TList *next;
    struct TList *prev;      /* for bidirectional list */
} TList;

typedef struct TStack {
    char name[100];
    char definition[500];
    Date dob;
    Date dod;
    struct TStack *next;
} TStack;

typedef struct TQNode {
    char name[100];
    char definition[500];
    Date dob;
    Date dod;
    struct TQNode *next;
} TQNode;

typedef struct {
    TQNode *front;
    TQNode *rear;
} TQueue;

typedef struct TTree {
    char name[100];
    char definition[500];
    Date dob;
    Date dod;
    struct TTree *left;
    struct TTree *right;
} TTree;


#endif /* TYPES_H */
