#ifndef RECURSION_H
#define RECURSION_H

#include <stdbool.h>
#include <stdio.h>
#include "types.h"
// Recursive operations on strings
int countOccurrences(const char *str, char ch);
int countOccurrencesRecursive(const char *str, char ch, int index);
void removeChar(char *str, char ch);
void removeCharRecursive(char *str, char ch, int index);
char* replaceChar(char *str, char oldChar, char newChar);
void replaceCharRecursive(char *str, char oldChar, char newChar, int index);
bool isPalindromeString(const char *str);
bool isPalindromeStringRecursive(const char *str, int left, int right);
void reverseString(char *str);
void reverseStringRecursive(char *str, int left, int right);
int stringLength(const char *str);
int stringLengthRecursive(const char *str);
int countWords(const char *str);
int countWordsRecursive(const char *str, int index);

// Recursive operations on files
int countLines(FILE *file);
int countLinesRecursive(FILE *file);
int countWordsFile(FILE *file);
int countWordsFileRecursive(FILE *file);
int countCharsFile(FILE *file);
int countCharsFileRecursive(FILE *file);
void processFileRecursive(FILE *file, void (*process)(char*));
void searchInFile(FILE *file, const char *searchTerm, bool *found);
void searchInFileRecursive(FILE *file, const char *searchTerm, bool *found);

// Recursive operations on linked lists
void printListRecursive(TList *head);
int countNodesRecursive(TList *head);
TList* searchRecursive(TList *head, const char *name);
void reverseListRecursive(TList **head);
TList* removeDuplicatesRecursive(TList *head);
TList* mergeSortedListsRecursive(TList *list1, TList *list2);
void splitListRecursive(TList *source, TList **front, TList **back, int n);
TList* findMiddleRecursive(TList *head);
bool isPalindromeListRecursive(TList *head, TList **left);
TList* rotateListRecursive(TList *head, int k);

// Recursive operations on stacks
void printStackRecursive(TStack *top);
int countStackNodesRecursive(TStack *top);
TStack* searchStackRecursive(TStack *top, const char *name);
void reverseStackRecursive(TStack **top);
TStack* removeStackDuplicatesRecursive(TStack *top);
TStack* rotateStackRecursive(TStack *top, int k);

// Recursive operations on BST
void inorderRecursive(TTree *root);
void preorderRecursive(TTree *root);
void postorderRecursive(TTree *root);
int heightRecursive(TTree *root);
int countTreeNodesRecursive(TTree *root);
int countLeafNodesRecursive(TTree *root);
int countInternalNodesRecursive(TTree *root);
TTree* searchTreeRecursive(TTree *root, const char *name);
TTree* findMinRecursive(TTree *root);
TTree* findMaxRecursive(TTree *root);
bool isBSTRecursive(TTree *root, int min, int max);
bool isBalancedRecursive(TTree *root);
TTree* mirrorRecursive(TTree *root);
void destroyRecursive(TTree *root);

// Recursive permutations and combinations
void printPermutations(char *str, int l, int r);
void printCombinations(char *str, int r, int index, char *data, int i);
int factorial(int n);
int fibonacci(int n);
int gcd(int a, int b);
int power(int a, int b);
int sumOfDigits(int n);
int reverseNumber(int n);
bool isArmstrong(int n);
bool isPrime(int n);
int sumOfArray(int arr[], int n);
int findMaxArray(int arr[], int n);
int findMinArray(int arr[], int n);
void reverseArray(int arr[], int start, int end);
bool isArraySorted(int arr[], int n);
int binarySearchRecursive(int arr[], int l, int r, int x);

// Recursive string operations for historical data
void processHistoricalNames(TList *head, void (*process)(const char*));
void searchHistoricalPattern(TList *head, const char *pattern, bool *found);
void filterByCentury(TList *head, int century, TList **result);
void sortByBirthYear(TList **head);
void groupByDeathYear(TList *head, TList **groups, int startYear, int endYear);

// Advanced recursive operations
void generateSubsets(int arr[], int n, int index, int subset[], int subsetSize);
void printSubsets(char *str, int index, char *subset);
int longestCommonSubsequence(const char *X, const char *Y, int m, int n);
int editDistance(const char *str1, const char *str2, int m, int n);
int knapsack(int weights[], int values[], int n, int capacity);
void towerOfHanoi(int n, char from, char to, char aux);
int countDistinctSubsequences(const char *str, int n);
int longestPalindromicSubsequence(const char *str, int i, int j);
int countLongestSubyear(TList *head, int startYear, int endYear);

// Missing functions from screenshots - Module 5: Recursion
int countOccurence(FILE *f, char *name);
FILE* removeOccurence(FILE *f, char *word);
FILE* replaceOccurence(FILE *f, char *name, char *DoB, char *DoD);
void namePermutation(char *name);
void subseqName(char *word);
void longestSubyear(char *date1, char *date2);
int distinctSubseqWord(char *event);
bool isPalindromeWord(char *event);

#endif /* RECURSION_H */
