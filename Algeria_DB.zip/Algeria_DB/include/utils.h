#ifndef UTILS_H
#define UTILS_H

#include "types.h"
#include <stdbool.h>
#include <stddef.h>
// Date utility functions
Date createDate(int day, int month, int year);
bool isValidDate(Date date);
int compareDates(Date date1, Date date2);
int calculateAge(Date dob, Date dod);
int daysBetweenDates(Date date1, Date date2);
Date addDaysToDate(Date date, int days);
Date subtractDaysFromDate(Date date, int days);
char* dateToString(Date date);
Date stringToDate(const char *dateStr);
int getDayOfWeek(Date date);
bool isLeapYear(int year);
int getDaysInMonth(int month, int year);

// String utility functions
void trimWhitespace(char *str);
void toLowerCase(char *str);
void toUpperCase(char *str);
bool startsWith(const char *str, const char *prefix);
bool endsWith(const char *str, const char *suffix);
bool contains(const char *str, const char *substring);
int countWords(const char *str);
char* substring(const char *str, int start, int end);
char* replaceSubstring(const char *str, const char *oldSub, const char *newSub);
void splitString(const char *str, char delimiter, char *result[], int *count);

// File utility functions
bool fileExists(const char *filename);
long getFileSize(const char *filename);
void saveListToFile(TList *head, const char *filename);
TList* loadListFromFile(const char *filename);
void savePersonalitiesToFile(TList *head, const char *filename);
TList* loadPersonalitiesFromFile(const char *filename);
void addPersonality(TList **head, const char *name, const char *definition, Date dob, Date dod);
bool createFile(const char *filename);
bool deleteFile(const char *filename);
bool copyFile(const char *source, const char *destination);
bool moveFile(const char *source, const char *destination);
void readFileContent(const char *filename, char *content);
void writeFileContent(const char *filename, const char *content);
void appendToFile(const char *filename, const char *content);

// Input validation functions
bool isValidName(const char *name);
bool isValidDefinition(const char *definition);
bool isValidYear(int year);
bool isValidMonth(int month);
bool isValidDay(int day);
void sanitizeInput(char *input);
void capitalizeWords(char *str);

// Historical data utility functions
void formatPersonalityInfo(TList *personality, char *output);
bool parsePersonalityLine(const char *line, char *name, char *definition, Date *dob, Date *dod);
bool isHistoricalFigure(const char *name);
int getCentury(Date date);
char* getHistoricalPeriod(Date date);
bool isContemporary(TList *person1, TList *person2);
int getAgeAtDeath(TList *personality);
void sortPersonalitiesByAge(TList **head);
void sortPersonalitiesByBirthYear(TList **head);
void sortPersonalitiesByDeathYear(TList **head);

// Display utility functions
void printSeparator(char ch, int count);
void printHeader(const char *title);
void printPersonalityCard(TList *personality);
void printPersonalityTable(TList *head);
void printStatistics(TList *head);
void printMenu();
void clearScreen();
void pauseExecution();

// Memory management functions
void* safeMalloc(size_t size);
void* safeRealloc(void *ptr, size_t size);
void safeFree(void **ptr);
void cleanupList(TList **head);
void cleanupStack(TStack **top);
void cleanupQueue(TQueue *q);
void cleanupTree(TTree *root);

// Error handling functions
void printError(const char *message);
void printSuccess(const char *message);
void printWarning(const char *message);
void printInfo(const char *message);
void logError(const char *function, const char *message);
void logInfo(const char *function, const char *message);

// Search and filter functions
TList* searchByName(TList *head, const char *name);
TList* searchByDefinition(TList *head, const char *keyword);
TList* searchByBirthYear(TList *head, int year);
TList* searchByDeathYear(TList *head, int year);
TList* searchByAgeRange(TList *head, int minAge, int maxAge);
TList* searchByCentury(TList *head, int century);
TList* filterByCriteria(TList *head, bool (*filter)(TList*, void*), void *criteria);

// Sorting functions
void sortByName(TList **head);
void sortByDefinition(TList **head);
void sortByBirthDate(TList **head);
void sortByDeathDate(TList **head);
void sortByAge(TList **head);
int compareNames(const char *name1, const char *name2);

// Conversion functions
TList* arrayToList(TList *array, int size);
TList** listToArray(TList *head, int *size);
TStack* listToStack(TList *head);
TList* stackToList(TStack *top);
TQueue* listToQueue(TList *head);
TList* queueToList(TQueue *q);
TTree* listToBST(TList *head);
TList* bstToList(TTree *root);

// Advanced utility functions
void backupData(TList *head, const char *backupFile);
void restoreData(TList **head, const char *backupFile);
void exportToCSV(TList *head, const char *filename);
void importFromCSV(TList **head, const char *filename);
void exportToJSON(TList *head, const char *filename);
void importFromJSON(TList **head, const char *filename);
void generateReport(TList *head, const char *reportFile);

#endif /* UTILS_H */
