#ifndef GUI_H
#define GUI_H

#include <stdbool.h>
#include <raylib.h>
#include "types.h"

/* ── Rendering Primitives ─────────────────────────────────── */
bool  GuiButton   (Rectangle b, const char *label, Color accent, float t);
bool  GuiSmallBtn (Rectangle b, const char *label, Color accent);
void  DrawCyberBG (float t);
void  DrawSidebar (float t, int modId);
void  DrawHeader  (const char *title, Color accent, bool *backClicked, float t);

/* ── Output Console ───────────────────────────────────────── */
#ifndef GUI_PRINTF_DECLARED
#define GUI_PRINTF_DECLARED
void  gui_printf      (const char *fmt, ...);
#endif
void  gui_clrscr      (void);
void  DrawOutputPanel (Rectangle bounds, float t);

/* ── Drawing Helpers ──────────────────────────────────────── */
void GlowRect(Rectangle r,Color c,float a,int th);
void NeonText(const char *t,int x,int y,int sz,Color c);
void Corners(Rectangle r,Color c,int L);

/* ── Visualizers ──────────────────────────────────────────── */
void DrawListVisualizer(TList *head, float t);
void DrawStackVisualizer(TStack *top, float t);
void DrawTreeVisualizer(TTree *root, float t);
void DrawDataExplorer(TList *head, float t);
void DrawDashboard(TList *head, float t);

/* ── Tactical Trace Visualizer ─────────────────────────────────── */
#define MAX_TRACE_STEPS 100
#define MAX_CALL_STACK_FRAMES 12

typedef struct {
    char description[128];
    char details[256];
    TList *listCopy;
    TStack *stackCopy;
    TTree *treeCopy;
    char callStack[MAX_CALL_STACK_FRAMES][64];
    int callStackDepth;
    int highlightedIndex;
    char highlightedName[100];
    int mathVal1;
    int mathVal2;
    int mathResult;
} TraceStep;

typedef struct {
    TraceStep steps[MAX_TRACE_STEPS];
    int count;
    int currentStep;
    bool active;
    bool playing;
    float playTimer;
    float speed;
    char title[128];
    int linkedModule;
    
    char tempStack[MAX_CALL_STACK_FRAMES][64];
    int tempStackDepth;
} TraceManager;

extern TraceManager g_trace;

void StartTrace(const char *title, int modId);
void EndTrace(void);
void ClearTrace(void);
void RecordStep(const char *desc, const char *details, TList *l, TStack *s, TTree *t, int highlightedIdx, const char *highlightedName);
void RecordMathStep(const char *desc, const char *details, int val1, int val2, int res);
void PushCallStack(const char *frame);
void PopCallStack(void);
void DrawTracePlayer(float t);
bool IsTraceActive(void);
void DrawAlgorithmCompanion(int modId);

/* Traced operations declarations */
void trace_bubble_sort(TList *head);
void trace_reverse_list(TList **head);
void trace_find_middle(TList *head);
void trace_is_palindrome(TList *head);
void trace_rotate_list(TList **head, int k);
void trace_push_stack(TStack **top, const char *name, const char *def, Date dob, Date dod);
void trace_pop_stack(TStack **top);
void trace_reverse_stack(TStack **top);
void trace_insert_bst(TTree **root, const char *name, const char *def, Date dob, Date dod);
void trace_delete_bst(TTree **root, const char *name);
void trace_search_bst(TTree *root, const char *name);
int  trace_factorial(int n);
int  trace_fibonacci(int n);
int  trace_gcd(int a, int b);
int  trace_power(int a, int b);
void trace_tower_of_hanoi(int n, char from, char to, char aux);
void trace_search_recursive_list(TList *head, const char *name);
void trace_reverse_list_recursive(TList **head);
void trace_reverse_stack_recursive(TStack **top);
int  trace_tree_height_recursive(TTree *root);
bool trace_is_balanced_recursive(TTree *root);



/* ── Input Form Overlay ───────────────────────────────────── */
void        FormBegin     (const char *title, int numFields, const char **labels);
bool        FormDraw      (float t);   /* returns true when submitted */
bool        FormCancelled (void);
const char *FormGet       (int i);
void        FormReset     (void);
bool        FormActive    (void);

/* ── Lifecycle ────────────────────────────────────────────── */
void ShowLandingPage (void);
void InitGUI         (void);
void CloseGUI        (void);
bool GUIShouldClose  (void);

#endif /* GUI_H */
