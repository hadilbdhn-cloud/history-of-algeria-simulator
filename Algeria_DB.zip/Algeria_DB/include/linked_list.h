#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdbool.h>
#include <stdio.h>
#include "types.h"
// Linked List operations
TList* createNode(const char *name, const char *definition, Date dob, Date dod);
void insertBeginning(TList **head, TList *newNode);
void insertEnd(TList **head, TList *newNode);
void insertAtPosition(TList **head, TList *newNode, int position);
void deleteNode(TList **head, const char *name);
void deleteAtPosition(TList **head, int position);
TList* searchNode(TList *head, const char *name);
void displayList(TList *head);
void displayListReverse(TList *head);
int countNodes(TList *head);
void sortList(TList **head);
void reverseList(TList **head);
TList* mergeSortedLists(TList *list1, TList *list2);
void splitList(TList *source, TList **front, TList **back);
TList* findMiddle(TList *head);
bool isPalindrome(TList *head);
void removeDuplicates(TList *head);
TList* rotateList(TList *head, int k);
void bubbleSort(TList *head);
void selectionSort(TList *head);
void insertionSort(TList **head);
void mergeSort(TList **head);
void quickSort(TList **head);
TList* partition(TList *head, TList *end, TList **newHead, TList **newEnd);
void quickSortRec(TList **head, TList *end);

// Queue operations
void initQueue(TQueue *q);
void enqueue(TQueue *q, const char *name, const char *definition, Date dob, Date dod);
TQNode* dequeue(TQueue *q);
TQNode* peekQueue(TQueue *q);
bool isQueueEmpty(TQueue *q);
void displayQueue(TQueue *q);
int queueSize(TQueue *q);
void clearQueue(TQueue *q);

// Historical data operations - Original
TList* getInfoByDates(TList *head, int startYear, int endYear);
TList* getInfoByDates2(TList *head, int startYear, int endYear);
void addPersonality(TList **head, const char *name, const char *definition, Date dob, Date dod);
void deletePersonality(TList **head, const char *name);
TList* searchPersonality(TList *head, const char *name);
void displayPersonalities(TList *head);
void savePersonalitiesToFile(TList *head, const char *filename);
TList* loadPersonalitiesFromFile(const char *filename);

// Missing functions from screenshots - Module 2: Linked Lists and Queues
TList* getPersonality(FILE *f);
TList* getDatePersonality(FILE *f);
void getInfoByDates_v2(TList *s, TList *DoB);
void getInfoByDates2_v2(TList *s, TList *DoD);
TList* sortWord(TList *syn);
TList* sortWord2(TList *syn);
TList* sortPersonality(TList *syn);
TList* deletepersonality(FILE *f, TList *s, TList *a, char *name);
TList* updatePersonality(FILE *f, TList *s, TList *a, char *name, char *definition, char *DoB, char *DoD);
TList* similarPersonality(TList *s, char *word);
TList* countPersonality(TList *s, Date *prt);
TList* palindromeName(TList *s);
TList* mergeNodes(TList *s, TList *a);
TList* merge2Nodes(TList *s, TList *a);
TList* addPersonality_v2(FILE *f, TList *s, TList *a, char *name, char *DoB, char *DoD);
TList* addEvents(TList *b, char *namEvente, char *date);
TQueue* sName(TList *s);
TQueue* ageP(TList *a);
TQueue* toQueue(TList *merged);

#endif /* LINKED_LIST_H */
