#include "../include/gui.h"
#include "../include/types.h"
#include "../include/linked_list.h"
#include "../include/bst.h"
#define WIN32_LEAN_AND_MEAN
#define NOGDI
#define NOUSER
#include <raylib.h>
#include <math.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* ═══════════════════════════════════════════════════════════
   PALETTE
═══════════════════════════════════════════════════════════ */
#define MAX_LINES 3000
#define LINE_LEN  512

void DrawListVisualizer(TList *head, float t);
void DrawStackVisualizer(TStack *top, float t);
void DrawTreeVisualizer(TTree *root, float t);

static Color C_BG    = {  2,  4,  8, 255};
static Color C_PANEL = {  7, 12, 22, 240};
static Color C_CYAN  = { 30, 220, 255, 255};
static Color C_GREEN = { 50, 255, 180, 255};
static Color C_AMBER = { 255, 180, 30, 255};
static Color C_RED   = { 255, 50, 70, 255};
static Color C_TEXT  = { 210, 230, 250, 255};
static Color C_DIM   = { 100, 130, 160, 255};
static Color C_MOD2  = { 40, 160, 255, 255};
static Color C_MOD3  = { 200, 80, 255, 255};
static Color C_MOD4  = { 255, 180, 60, 255};
static Color C_MOD5  = { 255, 90, 120, 255};

static Color NODE_COLORS[] = {
    { 30, 220, 255, 255}, // Cyan
    { 50, 255, 180, 255}, // Green
    { 255, 180, 30, 255}, // Amber
    { 200, 80, 255, 255}, // Purple
    { 255, 90, 120, 255}, // Pink
    { 255, 140, 50, 255}  // Orange
};
#define N_NODE_COLORS 6



/* ═══════════════════════════════════════════════════════════
   OUTPUT CONSOLE BUFFER
═══════════════════════════════════════════════════════════ */
#define MAX_LINES 3000
#define LINE_LEN  512

typedef struct { char text[LINE_LEN]; Color col; } CLine;
static CLine cbuf[MAX_LINES];
static int   ccount  = 0;
static int   cscroll = 0;

static void strip_ansi(char *s){
    char *r=s,*w=s;
    while(*r){ if(*r=='\033'){while(*r&&*r!='m')r++;if(*r)r++;}else *w++=*r++; }
    *w='\0';
}
static Color line_color(const char *s){
    if(strncmp(s,"OK:",3)==0)  return C_GREEN;
    if(strncmp(s,"ERR",3)==0)  return C_RED;
    if(strncmp(s,"===",3)==0)  return C_CYAN;
    if(strncmp(s,"---",3)==0)  return C_AMBER;
    if(strncmp(s,"  [",3)==0)  return (Color){150,200,255,255};
    return C_TEXT;
}
static void push_line(const char *txt){
    char tmp[LINE_LEN]; strncpy(tmp,txt,LINE_LEN-1); tmp[LINE_LEN-1]='\0';
    strip_ansi(tmp);
    if(ccount<MAX_LINES){
        strncpy(cbuf[ccount].text,tmp,LINE_LEN-1);
        cbuf[ccount].col=line_color(tmp);
        ccount++;
    } else {
        memmove(cbuf,cbuf+1,sizeof(CLine)*(MAX_LINES-1));
        strncpy(cbuf[MAX_LINES-1].text,tmp,LINE_LEN-1);
        cbuf[MAX_LINES-1].col=line_color(tmp);
    }
    int h = GetScreenHeight();
    int lh = 20;
    int mv = (h - 100) / lh;
    if(ccount > mv) cscroll = ccount - mv;
}


void gui_clrscr(void){ ccount=0; cscroll=0; }

void gui_printf(const char *fmt,...){
    char tmp[4096]; va_list ap; va_start(ap,fmt);
    vsnprintf(tmp,sizeof(tmp),fmt,ap); va_end(ap);
    char cur[LINE_LEN]={0}; int len=0;
    for(int i=0;tmp[i];i++){
        if(tmp[i]=='\n'){cur[len]='\0';push_line(cur);len=0;}
        else if(len<LINE_LEN-1) cur[len++]=tmp[i];
    }
    if(len){cur[len]='\0';push_line(cur);}
}

/* ═══════════════════════════════════════════════════════════
   DRAW HELPERS
═══════════════════════════════════════════════════════════ */
void GlowRect(Rectangle r,Color c,float a,int th){
    DrawRectangleLinesEx(r,th,Fade(c,a));
    DrawRectangleLinesEx((Rectangle){r.x-1,r.y-1,r.width+2,r.height+2},1,Fade(c,a*0.25f));
}
void NeonText(const char *t,int x,int y,int sz,Color c){
    DrawText(t,x+1,y+1,sz,Fade(BLACK,0.7f));
    DrawText(t,x,y,sz,c);
}
void Corners(Rectangle r,Color c,int L){
    int x=r.x,y=r.y,w=r.width,h=r.height;
    DrawLineEx((Vector2){x,y},(Vector2){x+L,y},2,c);
    DrawLineEx((Vector2){x,y},(Vector2){x,y+L},2,c);
    DrawLineEx((Vector2){x+w,y},(Vector2){x+w-L,y},2,c);
    DrawLineEx((Vector2){x+w,y},(Vector2){x+w,y+L},2,c);
    DrawLineEx((Vector2){x,y+h},(Vector2){x+L,y+h},2,c);
    DrawLineEx((Vector2){x,y+h},(Vector2){x,y+h-L},2,c);
    DrawLineEx((Vector2){x+w,y+h},(Vector2){x+w-L,y+h},2,c);
    DrawLineEx((Vector2){x+w,y+h},(Vector2){x+w,y+h-L},2,c);
}
static void GlowLine(Vector2 s, Vector2 e, Color c, float t) {
    float a = 0.5f + 0.5f * sinf(t * 4);
    DrawLineEx(s, e, 2, Fade(c, a));
    DrawLineEx(s, e, 4, Fade(c, a * 0.3f));
}


/* ═══════════════════════════════════════════════════════════
   FORM STATE (Moved up to be accessible by buttons)
═══════════════════════════════════════════════════════════ */
#define MAX_FORM_FIELDS 6
static struct {
    bool   active, submitted, cancelled, isDrawing;
    char   title[128];
    int    nfields, activeField;
    const  char *labels[MAX_FORM_FIELDS];
    char   values[MAX_FORM_FIELDS][256];
} F = {0};

/* ═══════════════════════════════════════════════════════════
   GUI BUTTON
═══════════════════════════════════════════════════════════ */
bool GuiButton(Rectangle b,const char *label,Color accent,float t){
    if(FormActive() && !F.isDrawing) {
        DrawRectangle(b.x,b.y,b.width,b.height,Fade(accent,0.05f));
        DrawRectangleLinesEx(b,1,Fade(accent,0.15f));
        int fs=14, tw=MeasureText(label,fs);
        while(tw>b.width-8 && fs>8) { fs--; tw=MeasureText(label,fs); }
        DrawText(label,(int)(b.x+b.width/2-tw/2),(int)(b.y+b.height/2-fs/2),fs,Fade(C_TEXT,0.3f));
        return false;
    }
    Vector2 mp=GetMousePosition();
    bool hover=CheckCollisionPointRec(mp,b);
    bool click=hover&&IsMouseButtonPressed(MOUSE_BUTTON_LEFT);

    float glow=hover?(0.55f+0.15f*sinf(t*6)):(0.25f+0.08f*sinf(t*2));
    DrawRectangle(b.x,b.y,b.width,b.height,Fade(accent,hover?0.22f:0.10f));
    GlowRect(b,accent,glow,hover?2:1);
    Corners(b,accent,10);

    /* label centered */
    int fs=14, tw=MeasureText(label,fs);
    while(tw>b.width-8 && fs>8) { fs--; tw=MeasureText(label,fs); }
    NeonText(label,(int)(b.x+b.width/2-tw/2),(int)(b.y+b.height/2-fs/2),fs,
             hover?WHITE:C_TEXT);
    return click;
}

bool GuiSmallBtn(Rectangle b,const char *label,Color accent){
    if(FormActive() && !F.isDrawing) {
        DrawRectangle(b.x,b.y,b.width,b.height,Fade(accent,0.1f));
        int tw=MeasureText(label,13);
        DrawText(label,(int)(b.x+b.width/2-tw/2),(int)(b.y+b.height/2-7),13,Fade(C_TEXT,0.3f));
        return false;
    }
    Vector2 mp=GetMousePosition();
    bool hover=CheckCollisionPointRec(mp,b);
    bool click=hover&&IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
    DrawRectangle(b.x,b.y,b.width,b.height,Fade(accent,hover?0.30f:0.15f));
    DrawRectangleLinesEx(b,1,Fade(accent,hover?0.9f:0.5f));
    int tw=MeasureText(label,13);
    NeonText(label,(int)(b.x+b.width/2-tw/2),(int)(b.y+b.height/2-7),13,
             hover?WHITE:C_TEXT);
    return click;
}

/* ═══════════════════════════════════════════════════════════
   BACKGROUNDS
═══════════════════════════════════════════════════════════ */
void DrawCyberBG(float t){
    ClearBackground(C_BG);
    int w = GetScreenWidth();
    int h = GetScreenHeight();
    float off=fmodf(t*12,40);
    for(int x=-(int)off;x<w;x+=40)
        DrawLineEx((Vector2){(float)x,0},(Vector2){(float)x,(float)h},1,Fade(C_CYAN,0.04f));
    for(int y=-(int)off;y<h;y+=40)
        DrawLineEx((Vector2){0,(float)y},(Vector2){(float)w,(float)y},1,Fade(C_CYAN,0.04f));
    
    /* scanlines */
    for(int i=0; i<h; i+=4)
        DrawRectangle(0, i, w, 1, Fade(BLACK, 0.1f));

    /* hex dots */
    for(int x=0;x<w;x+=60) for(int y=0;y<h;y+=60)
        DrawCircle(x,y,1,Fade(C_GREEN,0.07f));
}


/* ═══════════════════════════════════════════════════════════
   SIDEBAR (200 px wide)
═══════════════════════════════════════════════════════════ */
static const char *TIPS[]={
    "Type 0 or click BACK to go up.",
    "Scroll results with Mouse Wheel.",
    "Files save next to algeria.exe.",
    "BST auto-filled from linked list.",
    "Module 5: full recursive ops.",
    "Stack sorts by definition length.",
    "LCA needs two names in the BST.",
    "Permutations can be very long!",
    "Use Display All for a snapshot.",
    "Pre-loaded: 3 sample heroes.",
};
#define N_TIPS 10

void DrawSidebar(float t,int modId){
    int h = GetScreenHeight();
    DrawRectangle(0,0,200,h,Fade(C_PANEL,0.97f));
    GlowRect((Rectangle){0,0,200,h},C_CYAN,0.25f,1);

    NeonText("ALGERIA DB",10,12,18,C_CYAN);
    NeonText("Cyber Suite",10,34,12,C_DIM);
    DrawRectangle(10,54,180,1,Fade(C_CYAN,0.3f));

    /* Module nav pills */
    struct{ const char *n; Color c; int id;}mods[4]={
        {"M2  Linked Lists",C_MOD2,2},
        {"M3  Stacks",      C_MOD3,3},
        {"M4  BST",         C_MOD4,4},
        {"M5  Recursion",   C_MOD5,5},
    };
    for(int i=0;i<4;i++){
        bool active=(modId==mods[i].id);
        Rectangle pr={8,62+i*30,184,24};
        DrawRectangle(pr.x,pr.y,pr.width,pr.height,Fade(mods[i].c,active?0.25f:0.08f));
        if(active){ DrawRectangle(pr.x,pr.y,3,pr.height,mods[i].c); }
        DrawText(mods[i].n,pr.x+10,(int)(pr.y+5),13,active?WHITE:Fade(mods[i].c,0.8f));
    }

    DrawRectangle(10,183,180,1,Fade(C_DIM,0.3f));

    /* Rotating tip */
    int ti=(int)(t/5)%N_TIPS;
    DrawText("TIPS",10,192,11,Fade(C_GREEN,0.6f));
    /* simple word wrap */
    const char *tip=TIPS[ti];
    char word[64]=""; char ln[128]=""; int ty=208;
    for(const char *p=tip;;p++){
        if(*p==' '||*p=='\0'){
            char test[256]; snprintf(test,sizeof(test),"%s%s ",ln,word);
            if(MeasureText(test,12)>182){
                DrawText(ln,10,ty,12,C_DIM); ty+=15; snprintf(ln,sizeof(ln),"%s ",word);
            } else { snprintf(ln,sizeof(ln),"%s%s ",ln,word); }
            word[0]='\0';
            if(*p=='\0'){ DrawText(ln,10,ty,12,C_DIM); break; }
        } else { int wl=strlen(word); if(wl<63){word[wl]=*p;word[wl+1]='\0';} }
    }

    /* Radar pulse */
    int rx = 100, ry = h - 140;
    DrawCircleLines(rx, ry, 40, Fade(C_GREEN, 0.2f));
    DrawCircleLines(rx, ry, (int)(fmodf(t * 30, 40)), Fade(C_GREEN, 0.5f));
    float ang = t * 2;
    DrawLineEx((Vector2){(float)rx, (float)ry}, 
               (Vector2){(float)(rx + 40 * cosf(ang)), (float)(ry + 40 * sinf(ang))}, 2, C_GREEN);
    DrawText("CORE RADAR", rx - 30, ry + 45, 10, Fade(C_GREEN, 0.4f));

    /* Clock */
    time_t now=time(NULL); struct tm *lt=localtime(&now);
    char clk[16]; strftime(clk,sizeof(clk),"%H:%M:%S",lt);
    NeonText(clk,100-MeasureText(clk,16)/2,h-42,16,C_GREEN);
    DrawText("LOCAL TIME", 100-MeasureText("LOCAL TIME",10)/2, h-60, 10, Fade(C_DIM,0.5f));
}


/* ═══════════════════════════════════════════════════════════
   HEADER (x=200, y=0, w=1080, h=48)
═══════════════════════════════════════════════════════════ */
void DrawHeader(const char *title,Color accent,bool *backClicked,float t){
    int w = GetScreenWidth();
    DrawRectangle(200,0,w-200,48,Fade(C_PANEL,0.98f));
    DrawRectangle(200,47,w-200,2,accent);
    NeonText(title,216,10,24,accent);

    /* Animated pulse on title underline */
    float pw=MeasureText(title,24);
    float pa=0.3f+0.3f*sinf(t*3);
    DrawRectangle(216,36,(int)pw,1,Fade(accent,pa));

    /* Back button */
    Rectangle bb={w-130,8,120,32};
    if(GuiSmallBtn(bb,"< BACK",C_DIM)) *backClicked=true;

    DrawText(TextFormat("%.1fs",t),w-240,18,12,Fade(C_DIM,0.4f));
}

/* ═══════════════════════════════════════════════════════════
   OUTPUT PANEL  (right portion of screen)
═══════════════════════════════════════════════════════════ */
void DrawOutputPanel(Rectangle b,float t){
    DrawRectangleRec(b,Fade(C_PANEL,0.95f));
    DrawRectangleLinesEx(b,2,Fade(C_CYAN,0.5f));
    
    // Simple Header
    DrawRectangle(b.x, b.y, b.width, 32, Fade(C_CYAN, 0.2f));
    DrawText("SYSTEM TERMINAL LOG", (int)(b.x + 15), (int)(b.y + 8), 16, C_CYAN);

    /* Scroll logic */
    float wh = GetMouseWheelMove();
    if (CheckCollisionPointRec(GetMousePosition(), b)) {
        if (wh < 0) cscroll += 2;
        if (wh > 0) cscroll -= 2;
    }
    int lh = 20; // Taller lines for better readability
    int maxv = (int)((b.height - 48) / lh);
    if (cscroll > ccount - maxv) cscroll = ccount - maxv;
    if (cscroll < 0) cscroll = 0;


    /* Lines */
    for (int i = 0; i < maxv; i++) {
        int row = i + cscroll;
        if (row >= ccount) break;
        int ry = (int)(b.y + 40 + i * lh);
        
        // Simple, clear writing (no neon/glow)
        DrawText(cbuf[row].text, (int)(b.x + 15), ry, 15, cbuf[row].col);
    }

    /* Simple scrollbar */
    if (ccount > maxv) {
        float fr = (float)maxv / ccount;
        float po = (float)cscroll / ccount;
        int sh = (int)(b.height * fr);
        int sy = (int)(b.y + b.height * po);
        DrawRectangle(b.x + b.width - 6, b.y, 4, b.height, Fade(C_DIM, 0.2f));
        DrawRectangle(b.x + b.width - 6, sy, 4, sh, C_CYAN);
    }
}

/* ═══════════════════════════════════════════════════════════
   DATA VISUALIZERS (The "OH WOW" factor)
═══════════════════════════════════════════════════════════ */

void DrawListVisualizer(TList *head, float t) {
    int w = GetScreenWidth();
    int vx = 220, vy = 520, vw = w - 500 - 220 - 40;
    
    // Cyber-Panel Background
    Rectangle b = {(float)vx, (float)vy, (float)vw, 150};
    DrawRectangleRec(b, Fade(C_BG, 0.5f));
    DrawRectangleLinesEx(b, 1, Fade(C_CYAN, 0.3f));
    
    // Scanlines
    for(int y=vy; y<vy+150; y+=4) DrawRectangle(vx, y, vw, 1, Fade(C_BG, 0.4f));

    DrawText("REAL-TIME LINKED-LIST TOPOLOGY", vx+10, vy-25, 12, Fade(C_CYAN, 0.6f));

    TList *cur = head;
    int i = 0, nodeW = 100, nodeH = 40, gap = 40;
    while (cur && i < 6) {
        int nx = vx + 20 + i * (nodeW + gap);
        int ny = vy + 55;
        Rectangle nr = {(float)nx, (float)ny, (float)nodeW, (float)nodeH};
        Color nCol = NODE_COLORS[i % N_NODE_COLORS];
        
        // Node box with glow
        DrawRectangleRec(nr, Fade(nCol, 0.15f));
        GlowRect(nr, nCol, 0.4f, 1);
        DrawRectangleLinesEx(nr, 2, nCol);
        DrawText(TextFormat("%.10s..", cur->name), nx+8, ny+14, 12, WHITE);
        
        // Connection arrow with pulse
        if (cur->next && i < 5) {
            float pulse = 0.5f + 0.5f*sinf(t*5 + i);
            DrawLineEx((Vector2){(float)(nx+nodeW), (float)(ny+nodeH/2)}, 
                       (Vector2){(float)(nx+nodeW+gap), (float)(ny+nodeH/2)}, 2, Fade(nCol, pulse));
            DrawTriangle((Vector2){(float)(nx+nodeW+gap), (float)(ny+nodeH/2)},
                         (Vector2){(float)(nx+nodeW+gap-8), (float)(ny+nodeH/2-5)},
                         (Vector2){(float)(nx+nodeW+gap-8), (float)(ny+nodeH/2+5)}, nCol);
        }

        cur = cur->next; i++;
    }

    if (cur) DrawText("... [TRUNCATED]", vx+20 + i*(nodeW+gap), vy+65, 12, C_DIM);
}

void DrawStackVisualizer(TStack *top, float t) {
    int w = GetScreenWidth();
    int vx = 220, vy = 520;
    
    // Cyber-Silo Background
    Rectangle b = {(float)vx, (float)vy-50, 300, 350};
    DrawRectangleRec(b, Fade(C_BG, 0.4f));
    DrawRectangleLinesEx(b, 2, Fade(C_MOD3, 0.3f));
    for(int y=vy-50; y<vy+300; y+=4) DrawRectangle(vx, y, 300, 1, Fade(C_BG, 0.5f));

    DrawText("STACK MEMORY SILO", vx+10, vy-75, 12, Fade(C_MOD3, 0.6f));

    TStack *cur = top;
    int i = 0, nodeH = 32;
    while (cur && i < 8) {
        int nx = vx + 20;
        int ny = vy + 300 - 40 - i * (nodeH + 5);
        Rectangle nr = {(float)nx, (float)ny, 260.0f, (float)nodeH};
        
        Color nCol = NODE_COLORS[i % N_NODE_COLORS];
        DrawRectangleRec(nr, Fade(nCol, 0.2f));
        DrawRectangleLinesEx(nr, 2, nCol);
        DrawText(cur->name, nx+10, ny+8, 13, WHITE);
        cur = cur->next; i++;
    }


}

void DrawTreeVisualizer(TTree *root, float t) {
    int w = GetScreenWidth();
    int vx = 220, vy = 520, vw = w - 500 - 220 - 40;
    
    // Neural-Tree Background
    Rectangle b = {(float)vx, (float)vy-30, (float)vw, 250};
    DrawRectangleRec(b, Fade(C_BG, 0.5f));
    DrawRectangleLinesEx(b, 1, Fade(C_MOD4, 0.3f));
    for(int y=vy-30; y<vy+220; y+=4) DrawRectangle(vx, y, vw, 1, Fade(C_BG, 0.4f));

    DrawText("BST HIERARCHICAL MAPPING", vx+10, vy-55, 12, Fade(C_MOD4, 0.6f));
    
    void DrawNode(TTree *n, int x, int y, int hSpace, int depth) {

        if (!n) return;
        Color nCol = NODE_COLORS[depth % N_NODE_COLORS];
        if (n->left) {
            DrawLineEx((Vector2){(float)x, (float)y}, (Vector2){(float)(x-hSpace), (float)(y+50)}, 2, Fade(nCol, 0.3f));
            DrawNode(n->left, x-hSpace, y+50, hSpace/2, depth + 1);
        }
        if (n->right) {
            DrawLineEx((Vector2){(float)x, (float)y}, (Vector2){(float)(x+hSpace), (float)(y+50)}, 2, Fade(nCol, 0.3f));
            DrawNode(n->right, x+hSpace, y+50, hSpace/2, depth + 1);
        }
        DrawCircle(x, y, 18, C_PANEL);
        DrawCircleLines(x, y, 18, nCol);
        DrawText(TextFormat("%.3s", n->name), x-12, y-6, 12, WHITE);
    }
    
    DrawNode(root, vx + vw/2, vy + 40, vw/4, 0);

}

void DrawDataExplorer(TList *head, float t) {
    int w = GetScreenWidth(), h = GetScreenHeight();
    int ex = 220, ey = 70, ew = w - 500 - 220 - 20, eh = h - 70 - 20;
    
    DrawRectangleRec((Rectangle){(float)ex, (float)ey, (float)ew, (float)eh}, C_PANEL);
    GlowRect((Rectangle){(float)ex, (float)ey, (float)ew, (float)eh}, C_CYAN, 0.4f, 1);
    
    // Table Header
    DrawRectangle(ex, ey, ew, 36, Fade(C_CYAN, 0.2f));
    DrawText("NAME", ex + 20, ey + 10, 14, C_CYAN);
    DrawText("DEFINITION", ex + 180, ey + 10, 14, C_CYAN);
    DrawText("BORN", ex + ew - 150, ey + 10, 14, C_CYAN);
    DrawText("DIED", ex + ew - 80, ey + 10, 14, C_CYAN);
    
    int i = 0, rowH = 30;
    TList *cur = head;
    while (cur) {
        int ry = ey + 40 + i * rowH;
        if (ry + rowH > ey + eh) break;
        
        if (i % 2 == 0) DrawRectangle(ex, ry, ew, rowH, Fade(C_TEXT, 0.03f));
        
        DrawText(cur->name, ex + 20, ry + 8, 13, C_TEXT);
        DrawText(TextFormat("%.40s...", cur->definition), ex + 180, ry + 8, 13, C_DIM);
        DrawText(TextFormat("%04d", cur->dob.year), ex + ew - 150, ry + 8, 13, C_AMBER);
        DrawText(TextFormat("%04d", cur->dod.year), ex + ew - 80, ry + 8, 13, C_RED);
        
        cur = cur->next; i++;
    }
}

void DrawDashboard(TList *head, float t) {
    int w = GetScreenWidth(), h = GetScreenHeight();
    int dx = 220, dy = 320, dw = w - 500 - 220 - 40, dh = h - dy - 20;

    // Header Badge
    DrawRectangle(dx, dy - 240, dw, 220, Fade(C_PANEL, 0.8f));
    GlowRect((Rectangle){(float)dx, (float)(dy - 240), (float)dw, 220}, C_CYAN, 0.3f, 1);
    
    NeonText("SYSTEM CORE DASHBOARD", dx + 20, dy - 220, 18, C_CYAN);
    DrawRectangle(dx + 20, dy - 195, 200, 2, C_CYAN);
    
    // Stats Grid
    int count = 0; TList *c = head; while(c){ count++; c=c->next; }
    
    int sx = dx + 20, sy = dy - 170;
    DrawText("TOTAL RECORDS", sx, sy, 12, C_DIM);
    DrawText(TextFormat("%04d", count), sx, sy + 15, 28, NODE_COLORS[1]); // Green
    
    DrawText("DB INTEGRITY", sx + 180, sy, 12, C_DIM);
    DrawRectangle(sx + 180, sy + 20, 120, 12, Fade(C_BG, 0.8f));
    DrawRectangle(sx + 180, sy + 20, (int)(120 * (0.85f + 0.1f * sinf(t))), 12, NODE_COLORS[0]); // Cyan
    
    DrawText("ENCRYPTION", sx + 340, sy, 12, C_DIM);
    DrawText("AES-256-GCM", sx + 340, sy + 15, 20, NODE_COLORS[2]); // Amber


    // Decorative Visual: Data Stream
    int vstart = dx + 20, vtop = dy - 100, vh = 60;
    for(int i=0; i<10; i++) {
        float off = fmodf(t * 100 + i * 40, dw - 40);
        DrawRectangle((int)(vstart + off), vtop, 4, vh, Fade(C_GREEN, 0.4f));
    }
    DrawText("CORE DATA STREAM [ACTIVE]", vstart, vtop - 18, 10, Fade(C_GREEN, 0.6f));
    DrawRectangleLines(vstart, vtop, dw - 40, vh, Fade(C_GREEN, 0.2f));

    // Lower visualizer area label
    DrawText("MODULE TOPOLOGY PREVIEW", dx, dy - 15, 12, Fade(C_DIM, 0.6f));
    DrawRectangle(dx, dy - 2, dw, 1, Fade(C_DIM, 0.2f));
}



/* ═══════════════════════════════════════════════════════════
   FORM OVERLAY
═══════════════════════════════════════════════════════════ */
void FormBegin(const char *title,int n,const char **labels){
    memset(&F,0,sizeof(F));
    F.active=true;
    strncpy(F.title,title,127);
    F.nfields=n<MAX_FORM_FIELDS?n:MAX_FORM_FIELDS;
    for(int i=0;i<F.nfields;i++) F.labels[i]=labels[i];
}
bool FormActive(void)    { return F.active; }
bool FormCancelled(void) { return F.cancelled; }
const char *FormGet(int i){ return (i>=0&&i<F.nfields)?F.values[i]:""; }
void FormReset(void)     { memset(&F,0,sizeof(F)); }

bool FormDraw(float t){
    if(!F.active) return false;
    F.isDrawing = true;

    /* Darker background dimming */
    int w = GetScreenWidth();
    int h = GetScreenHeight();
    DrawRectangle(0,0,w,h,Fade(BLACK,0.85f));

    int fw=500, fh=80+F.nfields*68+60;
    int fx=(w-fw)/2, fy=(h-fh)/2;

    DrawRectangle(fx,fy,fw,fh,C_PANEL);
    GlowRect((Rectangle){fx,fy,fw,fh},C_CYAN,0.8f,2);
    Corners((Rectangle){fx,fy,fw,fh},C_GREEN,18);

    NeonText(F.title,fx+20,fy+16,18,C_CYAN);
    DrawRectangle(fx+10,fy+42,fw-20,1,Fade(C_CYAN,0.3f));

    /* Fields */
    for(int i=0;i<F.nfields;i++){
        int fy2=fy+56+i*68;
        bool active=(F.activeField==i);

        DrawText(F.labels[i],fx+20,fy2,13,active?C_AMBER:C_DIM);

        Rectangle fr={fx+20,fy2+18,fw-40,32};
        DrawRectangle(fr.x,fr.y,fr.width,fr.height,Fade(C_BG,0.8f));
        GlowRect(fr,active?C_AMBER:C_DIM,active?0.8f:0.3f,1);

        char display[258];
        snprintf(display,sizeof(display),"%s%s",F.values[i],
                 active&&((int)(t*2)%2==0)?"_":"");
        DrawText(display,(int)(fr.x+8),(int)(fr.y+8),14,active?WHITE:C_TEXT);

        if(active){
            /* Char input */
            int k=GetCharPressed();
            while(k>0){
                int vl=strlen(F.values[i]);
                if(k>=32&&k<=125&&vl<254){ F.values[i][vl]=k; F.values[i][vl+1]='\0'; }
                k=GetCharPressed();
            }
            if(IsKeyPressed(KEY_BACKSPACE)){
                int vl=strlen(F.values[i]); if(vl>0) F.values[i][vl-1]='\0';
            }
            if(IsKeyPressed(KEY_ENTER)||IsKeyPressed(KEY_TAB)){
                if(F.activeField<F.nfields-1) F.activeField++;
                else { F.submitted=true; F.active=false; return true; }
            }
            if(IsKeyPressed(KEY_UP)&&F.activeField>0) F.activeField--;
        }
        /* Click to focus */
        if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)&&
           CheckCollisionPointRec(GetMousePosition(),fr)) F.activeField=i;
    }

    /* Buttons */
    int bfy=fy+fh-52;
    Rectangle ok ={fx+fw-240,bfy,100,34};
    Rectangle can={fx+fw-130,bfy,100,34};
    if(GuiSmallBtn(ok,"CONFIRM",C_GREEN)){
        F.submitted=true; F.active=false; return true;
    }
    if(GuiSmallBtn(can,"CANCEL",C_RED)){
        F.cancelled=true; F.active=false;
    }
    DrawText("TAB/ENTER = next field  |  UP = prev field",fx+14,bfy+10,11,Fade(C_DIM,0.6f));

    /* ESC cancel */
    if(IsKeyPressed(KEY_ESCAPE)){ F.cancelled=true; F.active=false; }
    F.isDrawing = false;
    return false;
}

/* ═══════════════════════════════════════════════════════════
   LANDING PAGE
═══════════════════════════════════════════════════════════ */
static void DrawStar(float sx, float sy, float rOuter, float rInner, Color color) {
    float angleStep = PI / 5.0f; // 10 vertices (5 outer points, 5 inner valleys)
    Vector2 vertices[10];
    for (int i = 0; i < 10; i++) {
        float angle = -PI/2.0f + i * angleStep;
        float r = (i % 2 == 0) ? rOuter : rInner;
        vertices[i] = (Vector2){sx + cosf(angle) * r, sy + sinf(angle) * r};
    }
    // Draw 10 triangles centered at (sx, sy) with counter-clockwise winding to bypass face culling
    for (int i = 0; i < 10; i++) {
        Vector2 p1 = {sx, sy};
        Vector2 p2 = vertices[i];
        Vector2 p3 = vertices[(i + 1) % 10];
        DrawTriangle(p1, p3, p2, color);
    }
}

static void DrawAlgerianFlag(int x, int y, int w, int h) {
    Color algerianGreen = (Color){0, 102, 51, 255};
    Color algerianRed = (Color){210, 16, 52, 255};
    
    // 1. Draw green and white background halves
    DrawRectangle(x, y, w/2, h, algerianGreen);
    DrawRectangle(x + w/2, y, w/2, h, WHITE);
    DrawRectangleLines(x, y, w, h, Fade(WHITE, 0.4f));
    
    int cx = x + w/2;
    int cy = y + h/2;
    
    // 2. Crescent radii (2:3 official flag geometry approximation)
    float rOuter = h * 0.28f;
    float rInner = h * 0.23f;
    
    // Centered slightly to the left of the division line
    float ox = cx - h * 0.08f;
    DrawCircle((int)ox, cy, rOuter, algerianRed);
    
    // Unified inner mask center positioned slightly to the right of outer center
    float mx = cx - h * 0.02f;
    
    // Left half mask (Green) clipped exactly at flag center line
    BeginScissorMode(x, y, w/2, h);
    DrawCircle((int)mx, cy, rInner, algerianGreen);
    EndScissorMode();
    
    // Right half mask (White) clipped exactly at flag center line
    BeginScissorMode(cx, y, w/2, h);
    DrawCircle((int)mx, cy, rInner, WHITE);
    EndScissorMode();
    
    // 3. 5-Pointed Red Star inside crescent mouth
    float sx = cx + h * 0.12f;
    float sy = cy;
    DrawStar(sx, sy, h * 0.14f, h * 0.055f, algerianRed);
}

static void DrawMaqamEchahid(int cx, int cy, int h, float t) {
    Color c = C_CYAN;
    float pulse = 0.8f + 0.2f * sinf(t * 4.0f);
    
    // Left leaf curve
    DrawLineBezier((Vector2){(float)(cx - 30), (float)(cy + h/2)}, (Vector2){(float)(cx - 5), (float)(cy - h/2)}, 3.0f, Fade(c, pulse));
    // Right leaf curve
    DrawLineBezier((Vector2){(float)(cx + 30), (float)(cy + h/2)}, (Vector2){(float)(cx + 5), (float)(cy - h/2)}, 3.0f, Fade(c, pulse));
    // Center leaf curve
    DrawLineBezier((Vector2){(float)cx, (float)(cy + h/2)}, (Vector2){(float)cx, (float)(cy - h/2 + 20)}, 2.0f, Fade(c, pulse * 0.7f));
    
    // Base platform
    DrawRectangle(cx - 40, cy + h/2, 80, 6, Fade(c, 0.4f));
    DrawRectangleLines(cx - 40, cy + h/2, 80, 6, c);
    
    // Pulsing Eternal Flame at the center
    float flameR = 6.0f + 3.0f * sinf(t * 10.0f);
    DrawCircle(cx, cy + h/4, (int)flameR, C_AMBER);
}

void ShowLandingPage(void){
    if(!IsWindowReady()){
        InitWindow(1280,800,"Algeria DB - Central Command Suite");
        SetTargetFPS(60);
    }
    float t=0;
    while(!WindowShouldClose()){
        int w = GetScreenWidth();
        int h = GetScreenHeight();
        t+=GetFrameTime();
        BeginDrawing();
        DrawCyberBG(t);

        // Neon Outer border and scanlines
        GlowRect((Rectangle){15,15,(float)(w-30),(float)(h-30)},C_CYAN,0.8f,2);
        Corners((Rectangle){15,15,(float)(w-30),(float)(h-30)},C_GREEN,30);

        int sl=15+(int)((sinf(t*1.4f)+1)*0.5f*(h-30));
        DrawRectangleGradientH(15,sl,w/2,3,Fade(C_GREEN,0),Fade(C_GREEN,0.5f));
        DrawRectangleGradientH(15+w/2,sl,w/2-15,3,Fade(C_GREEN,0.5f),Fade(C_GREEN,0));

        /* School Badge & Header */
        const char *badge="NATIONAL HIGHER SCHOOL OF CYBERSECURITY";
        int bw=MeasureText(badge,16)+40,bx=(w-bw)/2;
        DrawRectangle(bx,35,bw,32,Fade(C_GREEN,0.12f));
        GlowRect((Rectangle){(float)bx,35.0f,(float)bw,32.0f},C_GREEN,0.6f,1);
        NeonText(badge,bx+20,43,16,C_GREEN);

        DrawText("Academic Session  2025 / 2026",
            w/2-MeasureText("Academic Session  2025 / 2026",13)/2,74,13,C_DIM);

        /* ── ALGERIAN FLAG & MAQAM ECHAHID Obelisks ── */
        int flagW = 200, flagH = 120; // Official 2:3 flag ratio
        int flagX = w/2 - flagW/2;
        int flagY = 140; // Shifted down to be completely below the school session text
        DrawAlgerianFlag(flagX, flagY, flagW, flagH);
        
        // Obelisks beautifully centered vertically relative to the flag
        DrawMaqamEchahid(flagX - 80, flagY + flagH/2, 120, t);
        DrawMaqamEchahid(flagX + flagW + 80, flagY + flagH/2, 120, t);

        /* Main Titles */
        float p=0.8f+0.2f*sinf(t*3.0f);
        const char *t1="HISTORY OF ALGERIA";
        const char *t2="DATABASE & CYBERSECURITY SIMULATOR";
        NeonText(t1,w/2-MeasureText(t1,42)/2,290,42,Fade(C_CYAN,p));
        NeonText(t2,w/2-MeasureText(t2,22)/2,340,22,Fade(C_GREEN,p));

        /* ── POWERFUL CHOUHADA TRIBUTE PLATE ── */
        int tw = 720, th = 80;
        int tx = w/2 - tw/2;
        int ty = 385; // Shifted down
        Rectangle tr = {(float)tx, (float)ty, (float)tw, (float)th};
        DrawRectangleRec(tr, Fade(C_RED, 0.08f));
        GlowRect(tr, C_RED, 0.7f, 2);
        DrawRectangleLinesEx(tr, 1.5f, C_RED);
        Corners(tr, C_RED, 12);
        
        const char *trib1 = "* GLORY TO THE 1.5 MILLION HEROIC MARTYRS *";
        const char *trib2 = "\"The blood of our Chouhada built the eternal state of Algeria\"";
        const char *trib3 = "NOVEMBER 1, 1954 - JULY 5, 1962";
        
        NeonText(trib1, w/2 - MeasureText(trib1, 16)/2, ty + 12, 16, C_AMBER);
        DrawText(trib2, w/2 - MeasureText(trib2, 13)/2, ty + 38, 13, C_TEXT);
        DrawText(trib3, w/2 - MeasureText(trib3, 11)/2, ty + 56, 11, Fade(C_TEXT, 0.6f));

        /* Module pills */
        struct{const char*n;Color c;}mp[4]={{"M2 Linked Lists",C_MOD2},{"M3 Stacks",C_MOD3},{"M4 BST",C_MOD4},{"M5 Recursion",C_MOD5}};
        int mw=200,mgap=16,mtotal=4*mw+3*mgap,mst=(w-mtotal)/2;
        for(int i=0;i<4;i++){
            Rectangle mr={(float)(mst+i*(mw+mgap)),490.0f,(float)mw,46.0f}; // Shifted down
            DrawRectangle(mr.x,mr.y,mr.width,mr.height,Fade(mp[i].c,0.12f));
            GlowRect(mr,mp[i].c,0.6f,1);
            Corners(mr,mp[i].c,8);
            NeonText(mp[i].n,(int)(mr.x+mw/2-MeasureText(mp[i].n,12)/2),(int)(mr.y+16),12,mp[i].c);
        }

        const char *d1="A comprehensive high-performance data-structure command center";
        DrawText(d1,w/2-MeasureText(d1,13)/2,550,13,C_DIM);

        Rectangle ar={w/2-240,580,480,48}; // Shifted down
        DrawRectangle(ar.x,ar.y,ar.width,ar.height,Fade(C_MOD3,0.08f));
        GlowRect(ar,C_MOD3,0.45f,1);
        DrawText("Presented by:",(int)(ar.x+16),(int)(ar.y+6),11,C_DIM);
        NeonText("Hadil Boudehane  &  Malak Ghomrani",
            (int)(ar.x+ar.width/2-MeasureText("Hadil Boudehane  &  Malak Ghomrani",16)/2),
            (int)(ar.y+23),16,C_TEXT);

        if((int)(t*2)%2==0){
            const char *ep="[ CLICK  OR  PRESS  ENTER  TO  LAUNCH  CENTRAL  COMMAND ]";
            int epw=MeasureText(ep,18);
            Rectangle er={(w-epw)/2.0f-20,650,epw+40,36}; // Shifted down
            DrawRectangle(er.x,er.y,er.width,er.height,Fade(C_CYAN,0.10f));
            GlowRect(er,C_CYAN,0.8f,2);
            NeonText(ep,(int)(er.x+20),(int)(er.y+9),18,C_CYAN);
        }

        /* Hints */
        DrawText("v1.0  |  2025-2026  |  ESISC",20,h-26,12,Fade(C_DIM,0.5f));
        DrawText("Raylib  |  C11",w-MeasureText("Raylib  |  C11",12)-20,h-26,12,Fade(C_DIM,0.5f));

        EndDrawing();
        if(IsKeyPressed(KEY_ENTER)||IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) break;
    }
}

/* ═══════════════════════════════════════════════════════════
   LIFECYCLE
═══════════════════════════════════════════════════════════ */
void InitGUI(void){
    if(!IsWindowReady()){
        InitWindow(GetScreenWidth(),GetScreenHeight(),"Algeria DB — Cybersecurity Suite");
        SetTargetFPS(60);
    }
    gui_clrscr();
    gui_printf("=== ALGERIA DATABASE SYSTEM READY ===");
    gui_printf("3 sample personalities pre-loaded.");
    gui_printf("Click any button to begin.");
    gui_printf("---");
}
void CloseGUI(void){ if(IsWindowReady()) CloseWindow(); }
bool GUIShouldClose(void){ return WindowShouldClose(); }

/* ── Deep Cloning & Release Helpers ───────────────────────────────── */
TList* cloneList(TList *head) {
    if (!head) return NULL;
    TList *newHead = NULL;
    TList *newTail = NULL;
    TList *curr = head;
    while (curr) {
        TList *node = (TList*)malloc(sizeof(TList));
        if (node) {
            memcpy(node, curr, sizeof(TList));
            node->next = NULL;
            node->prev = newTail;
            if (newTail) newTail->next = node;
            else newHead = node;
            newTail = node;
        }
        curr = curr->next;
    }
    return newHead;
}

void freeClonedList(TList *head) {
    while (head) {
        TList *temp = head;
        head = head->next;
        free(temp);
    }
}

TStack* cloneStack(TStack *top) {
    if (!top) return NULL;
    TStack *newTop = NULL;
    TStack *newTail = NULL;
    TStack *curr = top;
    while (curr) {
        TStack *node = (TStack*)malloc(sizeof(TStack));
        if (node) {
            memcpy(node, curr, sizeof(TStack));
            node->next = NULL;
            if (newTail) newTail->next = node;
            else newTop = node;
            newTail = node;
        }
        curr = curr->next;
    }
    return newTop;
}

void freeClonedStack(TStack *top) {
    while (top) {
        TStack *temp = top;
        top = top->next;
        free(temp);
    }
}

TTree* cloneTree(TTree *root) {
    if (!root) return NULL;
    TTree *node = (TTree*)malloc(sizeof(TTree));
    if (node) {
        memcpy(node, root, sizeof(TTree));
        node->left = cloneTree(root->left);
        node->right = cloneTree(root->right);
    }
    return node;
}

void freeClonedTree(TTree *root) {
    if (!root) return;
    freeClonedTree(root->left);
    freeClonedTree(root->right);
    free(root);
}

/* ── Tactical Trace Engine Backend ────────────────────────────────── */
TraceManager g_trace = {0};

void StartTrace(const char *title, int modId) {
    ClearTrace();
    g_trace.active = true;
    g_trace.playing = false;
    g_trace.playTimer = 0.0f;
    g_trace.speed = 1.0f;
    g_trace.currentStep = 0;
    g_trace.linkedModule = modId;
    strncpy(g_trace.title, title, sizeof(g_trace.title) - 1);
    g_trace.tempStackDepth = 0;
}

void EndTrace(void) {
    if (g_trace.count > 0) {
        g_trace.currentStep = 0;
    } else {
        g_trace.active = false;
    }
}

void ClearTrace(void) {
    g_trace.playing = false;
    for (int i = 0; i < g_trace.count; i++) {
        if (g_trace.steps[i].listCopy) freeClonedList(g_trace.steps[i].listCopy);
        if (g_trace.steps[i].stackCopy) freeClonedStack(g_trace.steps[i].stackCopy);
        if (g_trace.steps[i].treeCopy) freeClonedTree(g_trace.steps[i].treeCopy);
    }
    memset(g_trace.steps, 0, sizeof(g_trace.steps));
    g_trace.count = 0;
    g_trace.currentStep = 0;
    g_trace.active = false;
    g_trace.tempStackDepth = 0;
}

void RecordStep(const char *desc, const char *details, TList *l, TStack *s, TTree *t, int highlightedIdx, const char *highlightedName) {
    if (g_trace.count >= MAX_TRACE_STEPS) return;
    
    int idx = g_trace.count;
    TraceStep *step = &g_trace.steps[idx];
    
    strncpy(step->description, desc, sizeof(step->description) - 1);
    strncpy(step->details, details, sizeof(step->details) - 1);
    
    step->listCopy = cloneList(l);
    step->stackCopy = cloneStack(s);
    step->treeCopy = cloneTree(t);
    
    step->callStackDepth = g_trace.tempStackDepth;
    for (int i = 0; i < g_trace.tempStackDepth; i++) {
        strncpy(step->callStack[i], g_trace.tempStack[i], sizeof(step->callStack[i]) - 1);
    }
    
    step->highlightedIndex = highlightedIdx;
    if (highlightedName) {
        strncpy(step->highlightedName, highlightedName, sizeof(step->highlightedName) - 1);
    } else {
        step->highlightedName[0] = '\0';
    }
    
    step->mathVal1 = 0;
    step->mathVal2 = 0;
    step->mathResult = 0;
    
    g_trace.count++;
}

void RecordMathStep(const char *desc, const char *details, int val1, int val2, int res) {
    if (g_trace.count >= MAX_TRACE_STEPS) return;
    
    int idx = g_trace.count;
    TraceStep *step = &g_trace.steps[idx];
    
    strncpy(step->description, desc, sizeof(step->description) - 1);
    strncpy(step->details, details, sizeof(step->details) - 1);
    
    step->listCopy = NULL;
    step->stackCopy = NULL;
    step->treeCopy = NULL;
    
    step->callStackDepth = g_trace.tempStackDepth;
    for (int i = 0; i < g_trace.tempStackDepth; i++) {
        strncpy(step->callStack[i], g_trace.tempStack[i], sizeof(step->callStack[i]) - 1);
    }
    
    step->highlightedIndex = -1;
    step->highlightedName[0] = '\0';
    
    step->mathVal1 = val1;
    step->mathVal2 = val2;
    step->mathResult = res;
    
    g_trace.count++;
}

void PushCallStack(const char *frame) {
    if (g_trace.tempStackDepth >= MAX_CALL_STACK_FRAMES) return;
    strncpy(g_trace.tempStack[g_trace.tempStackDepth], frame, sizeof(g_trace.tempStack[g_trace.tempStackDepth]) - 1);
    g_trace.tempStackDepth++;
}

void PopCallStack(void) {
    if (g_trace.tempStackDepth > 0) {
        g_trace.tempStackDepth--;
    }
}

bool IsTraceActive(void) {
    return g_trace.active;
}

/* ── Tactical Trace UI Player ─────────────────────────────────────── */
void DrawTracePlayer(float t) {
    if (!g_trace.active || g_trace.count == 0) return;
    
    int w = GetScreenWidth();
    int h = GetScreenHeight();
    int vx = 220, vy = 500;
    int vw = w - 500 - 220 - 20;
    int vh = h - vy - 20;
    
    Rectangle b = {(float)vx, (float)vy, (float)vw, (float)vh};
    
    // Core Background Grid
    DrawRectangleRec(b, Fade(C_PANEL, 0.95f));
    GlowRect(b, C_GREEN, 0.5f, 2);
    Corners(b, C_GREEN, 15);
    
    // Header Bar
    DrawRectangle(vx, vy, vw, 30, Fade(C_GREEN, 0.15f));
    DrawLine(vx, vy + 30, vx + vw, vy + 30, Fade(C_GREEN, 0.4f));
    NeonText(TextFormat("★ ALGORITHMIC TACTICAL SIMULATOR: %s", g_trace.title), vx + 15, vy + 7, 14, C_GREEN);
    
    // Auto-Play Timer Logic
    if (g_trace.playing) {
        g_trace.playTimer += GetFrameTime();
        if (g_trace.playTimer >= g_trace.speed) {
            g_trace.playTimer = 0.0f;
            if (g_trace.currentStep < g_trace.count - 1) {
                g_trace.currentStep++;
            } else {
                g_trace.playing = false; // Stop at the end
            }
        }
    }
    
    TraceStep *step = &g_trace.steps[g_trace.currentStep];
    
    // ── TOP AREA: CONTROLS & CALL STACK ──
    int topY = vy + 35;
    int ctrlW = vw * 0.45f;
    int stackW = vw - ctrlW - 30;
    int stackX = vx + ctrlW + 15;
    
    // 1. Playback Controls Grid
    int btnX = vx + 15;
    int btnY = topY + 10;
    int bw = 32, bh = 28;
    
    // Backward Button
    if (GuiSmallBtn((Rectangle){(float)btnX, (float)btnY, (float)bw, (float)bh}, "<<", C_CYAN)) {
        g_trace.playing = false;
        if (g_trace.currentStep > 0) g_trace.currentStep--;
    }
    // Play/Pause Button
    const char *playLabel = g_trace.playing ? "||" : ">";
    if (GuiSmallBtn((Rectangle){(float)(btnX + bw + 6), (float)btnY, (float)bw, (float)bh}, playLabel, C_GREEN)) {
        g_trace.playing = !g_trace.playing;
        g_trace.playTimer = 0.0f;
    }
    // Forward Button
    if (GuiSmallBtn((Rectangle){(float)(btnX + (bw + 6)*2), (float)btnY, (float)bw, (float)bh}, ">>", C_CYAN)) {
        g_trace.playing = false;
        if (g_trace.currentStep < g_trace.count - 1) g_trace.currentStep++;
    }
    // Auto-Play Speed Selector
    char speedText[16];
    snprintf(speedText, sizeof(speedText), "%.1fs/step", g_trace.speed);
    if (GuiSmallBtn((Rectangle){(float)(btnX + (bw + 6)*3), (float)btnY, 80, (float)bh}, speedText, C_AMBER)) {
        if (g_trace.speed == 0.5f) g_trace.speed = 1.0f;
        else if (g_trace.speed == 1.0f) g_trace.speed = 2.0f;
        else g_trace.speed = 0.5f;
    }
    // Close / Reset Button
    if (GuiSmallBtn((Rectangle){(float)(btnX + (bw + 6)*3 + 86), (float)btnY, 64, (float)bh}, "RESET", C_RED)) {
        ClearTrace();
        return;
    }
    
    // Step tracker
    DrawText(TextFormat("STEP %02d / %02d", g_trace.currentStep + 1, g_trace.count), btnX, btnY + bh + 8, 12, C_DIM);
    
    // Description and Details
    DrawText(step->description, btnX, btnY + bh + 25, 14, C_AMBER);
    
    // Simple text wrapper for details
    char det[256];
    strncpy(det, step->details, sizeof(det)-1);
    det[sizeof(det)-1] = '\0';
    int textY = btnY + bh + 45;
    
    if (strlen(det) > 40) {
        char line1[45] = {0};
        char line2[200] = {0};
        int splitIdx = 40;
        while (splitIdx > 0 && det[splitIdx] != ' ') splitIdx--;
        if (splitIdx == 0) splitIdx = 40;
        
        strncpy(line1, det, splitIdx);
        strcpy(line2, det + splitIdx + 1);
        DrawText(line1, btnX, textY, 13, C_TEXT);
        DrawText(line2, btnX, textY + 16, 13, C_TEXT);
    } else {
        DrawText(det, btnX, textY, 13, C_TEXT);
    }
    
    // 2. Call Stack Pipeline (Overlapping plates with glowing paths)
    DrawRectangleLines(stackX, topY, stackW, 110, Fade(C_GREEN, 0.2f));
    DrawText("RECURSION CALL STACK PIPELINE", stackX + 10, topY + 6, 10, Fade(C_GREEN, 0.6f));
    
    int depth = step->callStackDepth;
    if (depth == 0) {
        DrawText("No active stack frames (Iterative)", stackX + 20, topY + 45, 12, C_DIM);
    } else {
        int maxDraw = depth < 5 ? depth : 5;
        for (int i = 0; i < maxDraw; i++) {
            int frameIdx = depth - 1 - i;
            int sy = topY + 80 - i * 16;
            int sx = stackX + 20 + i * 8;
            Rectangle frRec = {(float)sx, (float)sy, (float)(stackW - 60 - i * 16), 18.0f};
            
            Color col = (i == 0) ? NODE_COLORS[((int)(t*4)) % N_NODE_COLORS] : C_DIM;
            DrawRectangleRec(frRec, Fade(col, i == 0 ? 0.25f : 0.1f));
            DrawRectangleLinesEx(frRec, 1, col);
            DrawText(step->callStack[frameIdx], sx + 10, sy + 3, 11, i == 0 ? WHITE : C_TEXT);
            
            if (i > 0) {
                DrawLine(sx + 5, sy + 18, sx + 5 - 8, sy + 18 + 16, Fade(C_GREEN, 0.4f));
            }
        }
        if (depth > 5) {
            DrawText(TextFormat("+ %d more frames...", depth - 5), stackX + 20, topY + 12, 11, C_AMBER);
        }
    }
    
    DrawLine(vx + 10, topY + 115, vx + vw - 10, topY + 115, Fade(C_CYAN, 0.2f));
    
    // ── BOTTOM AREA: DATA STRUCTURE OR MATH SNAPSHOT ──
    int bottomY = topY + 120;
    
    if (step->listCopy) {
        int nodeW = 90, nodeH = 34, gap = 24;
        TList *cur = step->listCopy;
        int i = 0;
        
        DrawText("LIST SNAPSHOT AT THIS ITERATION", vx + 15, bottomY + 5, 11, Fade(C_CYAN, 0.6f));
        
        while (cur && i < 6) {
            int nx = vx + 30 + i * (nodeW + gap);
            int ny = bottomY + 30;
            Rectangle nr = {(float)nx, (float)ny, (float)nodeW, (float)nodeH};
            
            bool active = (step->highlightedIndex == i) || 
                          (step->highlightedName[0] != '\0' && strcmp(cur->name, step->highlightedName) == 0);
            
            Color nCol = active ? C_AMBER : NODE_COLORS[i % N_NODE_COLORS];
            
            DrawRectangleRec(nr, Fade(nCol, active ? 0.35f : 0.15f));
            GlowRect(nr, nCol, active ? 0.9f : 0.4f, active ? 2 : 1);
            DrawRectangleLinesEx(nr, active ? 2 : 1, nCol);
            
            DrawText(TextFormat("%.10s..", cur->name), nx + 8, ny + 10, 11, active ? C_AMBER : WHITE);
            
            if (cur->next && i < 5) {
                DrawLineEx((Vector2){(float)(nx + nodeW), (float)(ny + nodeH/2)}, 
                           (Vector2){(float)(nx + nodeW + gap), (float)(ny + nodeH/2)}, 2, Fade(nCol, 0.7f));
                DrawTriangle((Vector2){(float)(nx + nodeW + gap), (float)(ny + nodeH/2)},
                             (Vector2){(float)(nx + nodeW + gap - 6), (float)(ny + nodeH/2 - 4)},
                             (Vector2){(float)(nx + nodeW + gap - 6), (float)(ny + nodeH/2 + 4)}, nCol);
            }
            cur = cur->next; i++;
        }
        if (cur) DrawText("...", vx + 30 + i * (nodeW + gap), bottomY + 40, 12, C_DIM);
        
    } else if (step->stackCopy) {
        TStack *cur = step->stackCopy;
        int i = 0, nodeH = 24;
        
        DrawText("STACK SNAPSHOT AT THIS ITERATION", vx + 15, bottomY + 5, 11, Fade(C_MOD3, 0.6f));
        
        int nodeW = 100, gap = 15;
        while (cur && i < 6) {
            int nx = vx + 30 + i * (nodeW + gap);
            int ny = bottomY + 35;
            Rectangle nr = {(float)nx, (float)ny, (float)nodeW, (float)nodeH};
            
            bool active = (i == 0);
            Color nCol = active ? C_AMBER : NODE_COLORS[i % N_NODE_COLORS];
            
            DrawRectangleRec(nr, Fade(nCol, active ? 0.35f : 0.15f));
            DrawRectangleLinesEx(nr, active ? 2 : 1, nCol);
            DrawText(TextFormat("%.12s", cur->name), nx + 8, ny + 5, 11, active ? C_AMBER : WHITE);
            
            if (i == 0) DrawText("[TOP]", nx + nodeW/2 - 15, ny - 13, 9, C_AMBER);
            
            if (cur->next && i < 5) {
                DrawLine(nx + nodeW, ny + nodeH/2, nx + nodeW + gap, ny + nodeH/2, Fade(C_DIM, 0.5f));
            }
            
            cur = cur->next; i++;
        }
        
    } else if (step->treeCopy) {
        DrawText("BST HIERARCHICAL SNAPSHOT AT THIS ITERATION", vx + 15, bottomY + 5, 11, Fade(C_MOD4, 0.6f));
        
        void DrawMiniNode(TTree *n, int x, int y, int hSpace, int d) {
            if (!n) return;
            
            bool active = (step->highlightedName[0] != '\0' && strcmp(n->name, step->highlightedName) == 0);
            Color nCol = active ? C_AMBER : NODE_COLORS[d % N_NODE_COLORS];
            
            if (n->left) {
                DrawLineEx((Vector2){(float)x, (float)y}, (Vector2){(float)(x - hSpace), (float)(y + 24)}, 1.5f, Fade(nCol, 0.3f));
                DrawMiniNode(n->left, x - hSpace, y + 24, hSpace / 2, d + 1);
            }
            if (n->right) {
                DrawLineEx((Vector2){(float)x, (float)y}, (Vector2){(float)(x + hSpace), (float)(y + 24)}, 1.5f, Fade(nCol, 0.3f));
                DrawMiniNode(n->right, x + hSpace, y + 24, hSpace / 2, d + 1);
            }
            
            DrawCircle(x, y, 12, C_PANEL);
            DrawCircleLines(x, y, 12, nCol);
            if (active) DrawCircleLines(x, y, 14, C_AMBER);
            
            DrawText(TextFormat("%.3s", n->name), x - 9, y - 4, 9, active ? C_AMBER : WHITE);
        }
        
        DrawMiniNode(step->treeCopy, vx + vw / 2, bottomY + 25, vw / 8, 0);
        
    } else {
        DrawText("COMPUTATIONAL GRAPHIC PIPELINE", vx + 15, bottomY + 5, 11, Fade(C_GREEN, 0.6f));
        
        int startX = vx + 50;
        int startY = bottomY + 25;
        
        if (step->mathVal1 > 0) {
            int val1 = step->mathVal1;
            int val2 = step->mathVal2;
            int res = step->mathResult;
            
            char eq[64];
            if (strcmp(g_trace.title, "Factorial Recursion") == 0) {
                snprintf(eq, sizeof(eq), "%d * factorial(%d) = %d", val1, val1 - 1, res);
            } else if (strcmp(g_trace.title, "Fibonacci Recursion") == 0) {
                snprintf(eq, sizeof(eq), "fib(%d) + fib(%d) = %d", val1 - 1, val1 - 2, res);
            } else if (strcmp(g_trace.title, "GCD Recursion") == 0) {
                snprintf(eq, sizeof(eq), "gcd(%d, %d %% %d) = %d", val1, val1, val2, res);
            } else {
                snprintf(eq, sizeof(eq), "val1=%d, val2=%d, res=%d", val1, val2, res);
            }
            
            Rectangle eqRec = {(float)startX, (float)startY, (float)(vw - 100), 40.0f};
            DrawRectangleRec(eqRec, Fade(C_GREEN, 0.1f));
            DrawRectangleLinesEx(eqRec, 1.5f, C_GREEN);
            
            DrawText("Active Frame Equation:", startX + 15, startY + 6, 11, C_DIM);
            DrawText(eq, startX + 15, startY + 20, 14, C_GREEN);
            
            for (int d = 0; d < step->callStackDepth; d++) {
                DrawCircle(startX + d * 14 + 10, startY + 54, 4, NODE_COLORS[d % N_NODE_COLORS]);
                if (d < step->callStackDepth - 1) {
                    DrawLine(startX + d * 14 + 14, startY + 54, startX + (d + 1) * 14 + 6, startY + 54, Fade(C_DIM, 0.4f));
                }
            }
            DrawText("Nesting Depth", startX + step->callStackDepth * 14 + 15, startY + 50, 10, C_DIM);
        } else {
            DrawText("Processing operation outputs step-by-step...", vx + 30, bottomY + 35, 12, C_TEXT);
        }
    }
}

/* ── Algorithmic Quick Tips Companion ─────────────────────────────── */
void DrawAlgorithmCompanion(int modId) {
    int w = GetScreenWidth();
    int vx = 220, vy = 335;
    int vw = w - 500 - 220 - 20;
    int vh = 150;
    
    Rectangle r = {(float)vx, (float)vy, (float)vw, (float)vh};
    
    DrawRectangleRec(r, Fade(C_PANEL, 0.85f));
    DrawRectangleLinesEx(r, 1, Fade(C_CYAN, 0.3f));
    Corners(r, C_CYAN, 12);
    
    DrawRectangle(vx, vy, vw, 26, Fade(C_CYAN, 0.15f));
    DrawLine(vx, vy + 26, vx + vw, vy + 26, Fade(C_CYAN, 0.3f));
    NeonText("★ ALGORITHM COMMAND COMPANION & QUICK INSIGHTS", vx + 12, vy + 6, 12, C_CYAN);
    
    const char *title = "";
    const char *tip1 = "";
    const char *tip2 = "";
    const char *tip3 = "";
    Color themeCol = C_TEXT;
    
    if (modId == 2) {
        title = "Module 2: Linked Lists & Queues Guidance";
        tip1 = "• Dynamic Pointers: Double-linked elements store both 'next' and 'prev' links for bidirectional travel.";
        tip2 = "• Finding Middle: Employs slow (1 node/step) and fast (2 nodes/step) pointers until fast hits the end.";
        tip3 = "• FIFO Queues: First-In First-Out rule ensures the oldest enqueued hero is processed first.";
        themeCol = C_MOD2;
    } else if (modId == 3) {
        title = "Module 3: Stacks Logic & Backtracking";
        tip1 = "• LIFO Order: Last-In First-Out structure means the latest pushed hero is popped first.";
        tip2 = "• Memory Silo: Useful for keeping track of prior operations, history backtracks, and nested calls.";
        tip3 = "• Stack Reversal: Achieved elegantly using recursion frames without any extra collection variables.";
        themeCol = C_MOD3;
    } else if (modId == 4) {
        title = "Module 4: Binary Search Trees Alignment";
        tip1 = "• BST Sorting: Nodes left of root are smaller; nodes right of root are larger alphabetically.";
        tip2 = "• Inorder Travel: Visiting Left child, then Root, then Right prints all records alphabetically.";
        tip3 = "• LCA Ancestor: Identifies the first shared common split-node for two targeted hero nodes.";
        themeCol = C_MOD4;
    } else if (modId == 5) {
        title = "Module 5: Recursion & Mathematical Callstacks";
        tip1 = "• Base Case Rule: Every recursive routine must declare a terminating base case to avoid stack overflow.";
        tip2 = "• Winding/Unwinding: Watch how stack frames compile (push) and resolve (pop) recursively.";
        tip3 = "• Hanoi Transfers: Solved in O(2^n) steps. Divides peg movement into subproblems recursively.";
        themeCol = C_MOD5;
    } else {
        return;
    }
    
    DrawText(title, vx + 15, vy + 35, 13, themeCol);
    DrawText(tip1, vx + 15, vy + 58, 12, C_TEXT);
    DrawText(tip2, vx + 15, vy + 84, 12, C_TEXT);
    DrawText(tip3, vx + 15, vy + 110, 12, C_TEXT);
}

/* ── Tracing Algorithmic Implementation Wrappers ──────────────────── */
void trace_bubble_sort(TList *head) {
    StartTrace("Bubble Sort List", 2);
    TList *curr = head;
    int count = countNodes(head);
    
    RecordStep("Initial State", "Starting bubble sort...", head, NULL, NULL, -1, "");
    
    for (int i = 0; i < count - 1; i++) {
        TList *jNode = head;
        for (int j = 0; j < count - i - 1; j++) {
            TList *next = jNode->next;
            
            char details[256];
            snprintf(details, sizeof(details), "Comparing '%s' and '%s'", jNode->name, next->name);
            RecordStep("Compare Nodes", details, head, NULL, NULL, j, jNode->name);
            
            if (strcmp(jNode->name, next->name) > 0) {
                char tempName[100];
                char tempDef[500];
                Date tempDob, tempDod;
                
                strcpy(tempName, jNode->name);
                strcpy(tempDef, jNode->definition);
                tempDob = jNode->dob;
                tempDod = jNode->dod;
                
                strcpy(jNode->name, next->name);
                strcpy(jNode->definition, next->definition);
                jNode->dob = next->dob;
                jNode->dod = next->dod;
                
                strcpy(next->name, tempName);
                strcpy(next->definition, tempDef);
                next->dob = tempDob;
                next->dod = tempDod;
                
                snprintf(details, sizeof(details), "Swapped values of '%s' and '%s'", jNode->name, next->name);
                RecordStep("Swap Nodes", details, head, NULL, NULL, j + 1, next->name);
            }
            jNode = jNode->next;
        }
    }
    
    RecordStep("Sorted State", "Bubble sort completed successfully!", head, NULL, NULL, -1, "");
    EndTrace();
}

void trace_reverse_list(TList **headRef) {
    StartTrace("Reverse Linked List", 2);
    TList *head = *headRef;
    RecordStep("Initial State", "Starting list reversal...", head, NULL, NULL, -1, "");
    
    if (!head || !head->next) {
        RecordStep("Finished", "List is empty or has 1 node. Reversal trivial.", head, NULL, NULL, -1, "");
        EndTrace();
        return;
    }
    
    TList *prev = NULL;
    TList *current = head;
    TList *next = NULL;
    int idx = 0;
    
    while (current != NULL) {
        next = current->next;
        
        char details[256];
        snprintf(details, sizeof(details), "Point '%s' -> next to '%s' (prev was '%s')", 
                 current->name, prev ? prev->name : "NULL", next ? next->name : "NULL");
        
        current->next = prev;
        current->prev = next;
        
        prev = current;
        current = next;
        
        *headRef = prev;
        RecordStep("Reversed Link", details, prev, NULL, NULL, idx, prev->name);
        idx++;
    }
    *headRef = prev;
    RecordStep("Completed", "Reversal finished!", *headRef, NULL, NULL, -1, "");
    EndTrace();
}

void trace_find_middle(TList *head) {
    StartTrace("Find Middle Node", 2);
    RecordStep("Initial State", "Starting Slow/Fast pointer traversal...", head, NULL, NULL, -1, "");
    
    if (!head) {
        RecordStep("Empty List", "List is empty, middle node is NULL", head, NULL, NULL, -1, "");
        EndTrace();
        return;
    }
    
    TList *slow = head;
    TList *fast = head;
    int idxSlow = 0, idxFast = 0;
    
    RecordStep("Pointers At Start", "Both slow and fast pointers start at the head node.", head, NULL, NULL, 0, slow->name);
    
    while (fast && fast->next) {
        slow = slow->next;
        idxSlow++;
        fast = fast->next->next;
        idxFast += 2;
        
        char details[256];
        snprintf(details, sizeof(details), "Slow moves 1 step to '%s' (idx %d). Fast moves 2 steps to '%s' (idx %d).", 
                 slow->name, idxSlow, fast ? fast->name : "NULL", idxFast);
        RecordStep("Traversal step", details, head, NULL, NULL, idxSlow, slow->name);
    }
    
    char details[256];
    snprintf(details, sizeof(details), "Fast reached end! Middle node is slow: '%s'.", slow->name);
    RecordStep("Target Found", details, head, NULL, NULL, idxSlow, slow->name);
    EndTrace();
}

void trace_is_palindrome(TList *head) {
    StartTrace("List Palindrome Verification", 2);
    RecordStep("Initial State", "Checking if the linked list names form a palindrome...", head, NULL, NULL, -1, "");
    
    if (!head) {
        RecordStep("Empty List", "Empty list is a palindrome.", head, NULL, NULL, -1, "");
        EndTrace();
        return;
    }
    
    int count = countNodes(head);
    TList **arr = (TList**)malloc(sizeof(TList*) * count);
    TList *curr = head;
    for (int i = 0; i < count; i++) {
        arr[i] = curr;
        curr = curr->next;
    }
    
    bool palindrome = true;
    int left = 0;
    int right = count - 1;
    
    while (left < right) {
        char details[256];
        snprintf(details, sizeof(details), "Comparing front '%s' with back '%s'", arr[left]->name, arr[right]->name);
        RecordStep("Verify Characters", details, head, NULL, NULL, left, arr[left]->name);
        
        if (strcmp(arr[left]->name, arr[right]->name) != 0) {
            snprintf(details, sizeof(details), "Mismatch! '%s' != '%s'. Not a palindrome.", arr[left]->name, arr[right]->name);
            RecordStep("Mismatch Detected", details, head, NULL, NULL, left, arr[left]->name);
            palindrome = false;
            break;
        }
        
        left++;
        right--;
    }
    
    if (palindrome) {
        RecordStep("Confirmed", "Success! All nodes match. The list is a palindrome.", head, NULL, NULL, -1, "");
    }
    
    free(arr);
    EndTrace();
}

void trace_rotate_list(TList **headRef, int k) {
    StartTrace("Rotate List by K", 2);
    TList *head = *headRef;
    RecordStep("Initial State", "Starting list rotation...", head, NULL, NULL, -1, "");
    
    if (!head || k <= 0) {
        RecordStep("No Rotation", "K <= 0 or empty list. Rotation omitted.", head, NULL, NULL, -1, "");
        EndTrace();
        return;
    }
    
    int count = countNodes(head);
    k = k % count;
    if (k == 0) {
        RecordStep("Full Rotation", "K is multiple of size. List stays identical.", head, NULL, NULL, -1, "");
        EndTrace();
        return;
    }
    
    TList *curr = head;
    int idx = 1;
    while (idx < count - k && curr) {
        curr = curr->next;
        idx++;
    }
    
    TList *newHead = curr->next;
    TList *breakNode = curr;
    
    RecordStep("Find Pivot Node", "Locating the split pivot node...", head, NULL, NULL, idx-1, breakNode->name);
    
    TList *tail = newHead;
    while (tail->next) {
        tail = tail->next;
    }
    
    char details[256];
    snprintf(details, sizeof(details), "Pointers linked: join tail '%s' -> head '%s', then split after '%s'", 
             tail->name, head->name, breakNode->name);
    
    tail->next = head;
    head->prev = tail;
    breakNode->next = NULL;
    newHead->prev = NULL;
    
    *headRef = newHead;
    
    RecordStep("Pointers Rearranged", details, newHead, NULL, NULL, 0, newHead->name);
    EndTrace();
}

void trace_push_stack(TStack **top, const char *name, const char *def, Date dob, Date dod) {
    StartTrace("Stack Push", 3);
    RecordStep("Initial State", "Preparing to push new element to the stack...", NULL, *top, NULL, -1, "");
    
    TStack *newNode = (TStack*)malloc(sizeof(TStack));
    strcpy(newNode->name, name);
    strcpy(newNode->definition, def);
    newNode->dob = dob;
    newNode->dod = dod;
    newNode->next = *top;
    *top = newNode;
    
    RecordStep("Pushed Element", TextFormat("Pushed '%s' onto stack silo top.", name), NULL, *top, NULL, 0, name);
    EndTrace();
}

void trace_pop_stack(TStack **top) {
    StartTrace("Stack Pop", 3);
    RecordStep("Initial State", "Preparing to pop top element from stack...", NULL, *top, NULL, -1, "");
    
    if (!*top) {
        RecordStep("Stack Empty", "Underflow! The stack is empty.", NULL, NULL, NULL, -1, "");
        EndTrace();
        return;
    }
    
    TStack *temp = *top;
    *top = (*top)->next;
    
    RecordStep("Popped Node", TextFormat("Successfully popped '%s' from top of the stack.", temp->name), NULL, *top, NULL, -1, "");
    free(temp);
    EndTrace();
}

void trace_reverse_stack(TStack **top) {
    StartTrace("Reverse Stack", 3);
    RecordStep("Initial State", "Starting Stack reversal...", NULL, *top, NULL, -1, "");
    
    TStack *curr = *top;
    int count = 0;
    while (curr) { count++; curr = curr->next; }
    
    if (count <= 1) {
        RecordStep("Trivial Reversal", "Reversal trivial for <= 1 element.", NULL, *top, NULL, -1, "");
        EndTrace();
        return;
    }
    
    TStack *revTop = NULL;
    TStack *orig = *top;
    
    while (orig) {
        TStack *temp = orig;
        orig = orig->next;
        
        temp->next = revTop;
        revTop = temp;
        
        RecordStep("Transfer Top Node", TextFormat("Popped '%s' from old stack and pushed to reversed stack.", revTop->name), NULL, revTop, NULL, 0, revTop->name);
    }
    
    *top = revTop;
    RecordStep("Reversed Successfully", "Reversal finished!", NULL, *top, NULL, -1, "");
    EndTrace();
}

TTree* trace_insert_bst_rec(TTree *root, const char *name, const char *def, Date dob, Date dod, TTree **fullRoot, int depth) {
    char frame[64];
    snprintf(frame, sizeof(frame), "insertBST(%s)", root ? root->name : "NULL");
    PushCallStack(frame);
    
    if (!root) {
        TTree *node = createBSTNode(name, def, dob, dod);
        if (!*fullRoot) *fullRoot = node;
        RecordStep("Base Case reached", TextFormat("Created new leaf node for '%s'", name), NULL, NULL, *fullRoot, depth, name);
        PopCallStack();
        return node;
    }
    
    if (strcmp(name, root->name) < 0) {
        RecordStep("Traverse Left", TextFormat("'%s' < '%s', going Left...", name, root->name), NULL, NULL, *fullRoot, depth, root->name);
        root->left = trace_insert_bst_rec(root->left, name, def, dob, dod, fullRoot, depth + 1);
    } else {
        RecordStep("Traverse Right", TextFormat("'%s' >= '%s', going Right...", name, root->name), NULL, NULL, *fullRoot, depth, root->name);
        root->right = trace_insert_bst_rec(root->right, name, def, dob, dod, fullRoot, depth + 1);
    }
    
    PopCallStack();
    return root;
}

void trace_insert_bst(TTree **root, const char *name, const char *def, Date dob, Date dod) {
    StartTrace("BST Node Insertion", 4);
    RecordStep("Initial State", TextFormat("Beginning insertion of '%s' into BST...", name), NULL, NULL, *root, -1, "");
    
    *root = trace_insert_bst_rec(*root, name, def, dob, dod, root, 0);
    
    RecordStep("Finished", TextFormat("Node '%s' inserted successfully.", name), NULL, NULL, *root, -1, "");
    EndTrace();
}

TTree* trace_delete_bst_rec(TTree *root, const char *name, TTree **fullRoot, int depth) {
    if (!root) {
        return NULL;
    }
    
    char frame[64];
    snprintf(frame, sizeof(frame), "deleteBST(%s)", root->name);
    PushCallStack(frame);
    
    int comp = strcmp(name, root->name);
    if (comp < 0) {
        RecordStep("Traverse Left", TextFormat("'%s' < '%s', searching in left subtree to delete...", name, root->name), NULL, NULL, *fullRoot, depth, root->name);
        root->left = trace_delete_bst_rec(root->left, name, fullRoot, depth + 1);
    } else if (comp > 0) {
        RecordStep("Traverse Right", TextFormat("'%s' > '%s', searching in right subtree to delete...", name, root->name), NULL, NULL, *fullRoot, depth, root->name);
        root->right = trace_delete_bst_rec(root->right, name, fullRoot, depth + 1);
    } else {
        RecordStep("Node Identified", TextFormat("Found target node '%s' to delete. Resolving cases...", root->name), NULL, NULL, *fullRoot, depth, root->name);
        
        if (!root->left) {
            RecordStep("Case 1: No Left Child", "Replacing target node with its right child.", NULL, NULL, *fullRoot, depth, root->name);
            TTree *temp = root->right;
            if (root == *fullRoot) *fullRoot = temp;
            free(root);
            PopCallStack();
            return temp;
        } else if (!root->right) {
            RecordStep("Case 2: No Right Child", "Replacing target node with its left child.", NULL, NULL, *fullRoot, depth, root->name);
            TTree *temp = root->left;
            if (root == *fullRoot) *fullRoot = temp;
            free(root);
            PopCallStack();
            return temp;
        }
        
        RecordStep("Case 3: Two Children", "Locating inorder successor (smallest in right subtree)...", NULL, NULL, *fullRoot, depth, root->name);
        TTree *succ = root->right;
        while (succ->left) succ = succ->left;
        
        RecordStep("Successor Found", TextFormat("Replacing target data with Successor '%s'.", succ->name), NULL, NULL, *fullRoot, depth, succ->name);
        strcpy(root->name, succ->name);
        strcpy(root->definition, succ->definition);
        root->dob = succ->dob;
        root->dod = succ->dod;
        
        RecordStep("Delete Successor Leaf", "Recursively deleting successor node from right subtree...", NULL, NULL, *fullRoot, depth, succ->name);
        root->right = trace_delete_bst_rec(root->right, succ->name, fullRoot, depth + 1);
    }
    
    PopCallStack();
    return root;
}

void trace_delete_bst(TTree **root, const char *name) {
    StartTrace("BST Node Deletion", 4);
    RecordStep("Initial State", TextFormat("Initiating delete for '%s' inside BST...", name), NULL, NULL, *root, -1, "");
    
    *root = trace_delete_bst_rec(*root, name, root, 0);
    
    RecordStep("Deletion Complete", "Node deleted.", NULL, NULL, *root, -1, "");
    EndTrace();
}

void trace_search_bst(TTree *root, const char *name) {
    StartTrace("BST Search", 4);
    RecordStep("Initial State", TextFormat("Searching for '%s' inside the BST...", name), NULL, NULL, root, -1, "");
    
    TTree *curr = root;
    int depth = 0;
    bool found = false;
    
    while (curr) {
        char frame[64];
        snprintf(frame, sizeof(frame), "search(%s)", curr->name);
        PushCallStack(frame);
        
        int comp = strcmp(name, curr->name);
        if (comp == 0) {
            RecordStep("Match Found!", TextFormat("Successfully found target node '%s'!", name), NULL, NULL, root, depth, curr->name);
            PopCallStack();
            found = true;
            break;
        } else if (comp < 0) {
            RecordStep("Compare Left", TextFormat("'%s' < '%s', search left subtree.", name, curr->name), NULL, NULL, root, depth, curr->name);
            PopCallStack();
            curr = curr->left;
        } else {
            RecordStep("Compare Right", TextFormat("'%s' > '%s', search right subtree.", name, curr->name), NULL, NULL, root, depth, curr->name);
            PopCallStack();
            curr = curr->right;
        }
        depth++;
    }
    
    if (!found) {
        RecordStep("Not Found", TextFormat("Completed traversal. Target '%s' is not in BST.", name), NULL, NULL, root, -1, "");
    }
    
    EndTrace();
}

int trace_factorial_rec(int n) {
    char frame[64];
    snprintf(frame, sizeof(frame), "factorial(%d)", n);
    PushCallStack(frame);
    
    if (n <= 1) {
        RecordMathStep("Base Case reached", "factorial(1) = 1. Terminating recursion.", n, 0, 1);
        PopCallStack();
        return 1;
    }
    
    RecordMathStep("Recursive step", TextFormat("factorial(%d) calls %d * factorial(%d)", n, n, n-1), n, 0, 0);
    int sub = trace_factorial_rec(n - 1);
    int res = n * sub;
    
    char details[256];
    snprintf(details, sizeof(details), "factorial(%d) resolves to %d * %d = %d", n, n, sub, res);
    RecordMathStep("Resolving Multiplication", details, n, sub, res);
    
    PopCallStack();
    return res;
}

int trace_factorial(int n) {
    StartTrace("Factorial Recursion", 5);
    int result = trace_factorial_rec(n);
    EndTrace();
    return result;
}

int trace_fibonacci_rec(int n) {
    char frame[64];
    snprintf(frame, sizeof(frame), "fibonacci(%d)", n);
    PushCallStack(frame);
    
    if (n <= 1) {
        RecordMathStep("Base Case reached", TextFormat("fibonacci(%d) = %d.", n, n), n, 0, n);
        PopCallStack();
        return n;
    }
    
    RecordMathStep("Branching Left", TextFormat("fibonacci(%d) calling fibonacci(%d)", n, n-1), n, 0, 0);
    int left = trace_fibonacci_rec(n - 1);
    
    RecordMathStep("Branching Right", TextFormat("fibonacci(%d) calling fibonacci(%d)", n, n-2), n, 0, 0);
    int right = trace_fibonacci_rec(n - 2);
    
    int res = left + right;
    char details[256];
    snprintf(details, sizeof(details), "Summing branches: fib(%d) + fib(%d) = %d + %d = %d", n-1, n-2, left, right, res);
    RecordMathStep("Resolving Addition", details, n, 0, res);
    
    PopCallStack();
    return res;
}

int trace_fibonacci(int n) {
    StartTrace("Fibonacci Recursion", 5);
    int result = trace_fibonacci_rec(n);
    EndTrace();
    return result;
}

int trace_gcd_rec(int a, int b) {
    char frame[64];
    snprintf(frame, sizeof(frame), "gcd(%d, %d)", a, b);
    PushCallStack(frame);
    
    if (b == 0) {
        RecordMathStep("Base Case reached", TextFormat("b=0, returns gcd = %d.", a), a, b, a);
        PopCallStack();
        return a;
    }
    
    RecordMathStep("Recursive Euclidean step", TextFormat("gcd(%d, %d) calls gcd(%d, %d %% %d) = gcd(%d, %d)", a, b, b, a, b, b, a%b), a, b, 0);
    int res = trace_gcd_rec(b, a % b);
    
    RecordMathStep("Return value up", TextFormat("gcd(%d, %d) returning gcd = %d", a, b, res), a, b, res);
    PopCallStack();
    return res;
}

int trace_gcd(int a, int b) {
    StartTrace("GCD Recursion", 5);
    int result = trace_gcd_rec(a, b);
    EndTrace();
    return result;
}

int trace_power_rec(int a, int b) {
    char frame[64];
    snprintf(frame, sizeof(frame), "power(%d, %d)", a, b);
    PushCallStack(frame);
    
    if (b == 0) {
        RecordMathStep("Base Case reached", "power(a, 0) = 1.", a, b, 1);
        PopCallStack();
        return 1;
    }
    
    RecordMathStep("Recursive step", TextFormat("power(%d, %d) calls %d * power(%d, %d)", a, b, a, a, b-1), a, b, 0);
    int sub = trace_power_rec(a, b - 1);
    int res = a * sub;
    
    RecordMathStep("Resolving Power Multiplications", TextFormat("power(%d, %d) = %d * %d = %d", a, b, a, sub, res), a, sub, res);
    PopCallStack();
    return res;
}

int trace_power(int a, int b) {
    StartTrace("Power Recursion", 5);
    int result = trace_power_rec(a, b);
    EndTrace();
    return result;
}

void trace_tower_of_hanoi_rec(int n, char from, char to, char aux) {
    char frame[64];
    snprintf(frame, sizeof(frame), "hanoi(%d, %c, %c)", n, from, to);
    PushCallStack(frame);
    
    if (n == 1) {
        RecordMathStep("Base Case Hanoi", TextFormat("Move disk 1 from peg %c to peg %c", from, to), n, 0, 0);
        PopCallStack();
        return;
    }
    
    RecordMathStep("Divide Hanoi Subproblem 1", TextFormat("Solve for %d disks from %c to auxiliary %c", n-1, from, aux), n, 0, 0);
    trace_tower_of_hanoi_rec(n - 1, from, aux, to);
    
    RecordMathStep("Move Disk", TextFormat("Move disk %d from peg %c to peg %c", n, from, to), n, 0, 0);
    
    RecordMathStep("Divide Hanoi Subproblem 2", TextFormat("Solve for %d disks from auxiliary %c to %c", n-1, aux, to), n, 0, 0);
    trace_tower_of_hanoi_rec(n - 1, aux, to, from);
    
    PopCallStack();
}

void trace_tower_of_hanoi(int n, char from, char to, char aux) {
    StartTrace("Tower of Hanoi Recursion", 5);
    trace_tower_of_hanoi_rec(n, from, to, aux);
    EndTrace();
}

static TList* trace_search_recursive_list_rec(TList *head, TList *curr, const char *name, int depth) {
    TList *cloned = cloneList(head);
    if (curr == NULL) {
        PushCallStack("search(NULL)");
        RecordStep("Search Base Case: NULL", "Reached end of list. Element not found.", cloned, NULL, NULL, -1, NULL);
        PopCallStack();
        freeClonedList(cloned);
        return NULL;
    }
    
    char frame[128];
    snprintf(frame, sizeof(frame), "search(\"%s\")", curr->name);
    PushCallStack(frame);
    
    if (strcmp(curr->name, name) == 0) {
        RecordStep("Search Base Case: Match Found", TextFormat("Match found for '%s' at depth %d!", name, depth), cloned, NULL, NULL, -1, curr->name);
        PopCallStack();
        freeClonedList(cloned);
        return curr;
    }
    
    RecordStep("Recursive Search Step", TextFormat("Name '%s' != '%s'. Recursing next node.", curr->name, name), cloned, NULL, NULL, -1, curr->name);
    TList *res = trace_search_recursive_list_rec(head, curr->next, name, depth + 1);
    
    PopCallStack();
    freeClonedList(cloned);
    return res;
}

void trace_search_recursive_list(TList *head, const char *name) {
    StartTrace("Recursive List Search", 2);
    trace_search_recursive_list_rec(head, head, name, 1);
    EndTrace();
}

static TList* trace_reverse_list_recursive_rec(TList **head, TList *curr, TList **new_head) {
    TList *cloned = cloneList(*head);
    if (curr == NULL) {
        PushCallStack("reverse(NULL)");
        RecordStep("Reversal Base Case", "Empty list reached.", cloned, NULL, NULL, -1, NULL);
        PopCallStack();
        freeClonedList(cloned);
        return NULL;
    }
    if (curr->next == NULL) {
        char frame[128];
        snprintf(frame, sizeof(frame), "reverse(\"%s\")", curr->name);
        PushCallStack(frame);
        *new_head = curr;
        RecordStep("Reversal End Found", TextFormat("Node '%s' has no next. This is the new head.", curr->name), cloned, NULL, NULL, -1, curr->name);
        PopCallStack();
        freeClonedList(cloned);
        return curr;
    }
    
    char frame[128];
    snprintf(frame, sizeof(frame), "reverse(\"%s\")", curr->name);
    PushCallStack(frame);
    
    RecordStep("Reversal Winding Down", TextFormat("Winding deep recursion for '%s' -> '%s'.", curr->name, curr->next->name), cloned, NULL, NULL, -1, curr->name);
    trace_reverse_list_recursive_rec(head, curr->next, new_head);
    
    TList *nextNode = curr->next;
    nextNode->next = curr;
    curr->prev = nextNode;
    curr->next = NULL;
    
    *head = *new_head;
    TList *clonedUnwound = cloneList(*head);
    RecordStep("Reversal Unwinding Link Swap", TextFormat("Flipping pointer: '%s' now points to '%s'.", nextNode->name, curr->name), clonedUnwound, NULL, NULL, -1, curr->name);
    freeClonedList(clonedUnwound);
    
    PopCallStack();
    freeClonedList(cloned);
    return curr;
}

void trace_reverse_list_recursive(TList **head) {
    if (head == NULL || *head == NULL) return;
    StartTrace("Recursive List Reversal", 2);
    TList *new_head = NULL;
    trace_reverse_list_recursive_rec(head, *head, &new_head);
    *head = new_head;
    EndTrace();
}

static void trace_insert_at_bottom_stack_rec(TStack **top, TStack *item) {
    TStack *cloned = cloneStack(*top);
    if (*top == NULL) {
        PushCallStack("insertAtBottom(NULL)");
        *top = item;
        TStack *clonedInjected = cloneStack(*top);
        RecordStep("Insert Stack Bottom Base Case", TextFormat("Stack bottom reached. Depositing '%s'.", item->name), NULL, clonedInjected, NULL, -1, item->name);
        PopCallStack();
        freeClonedStack(clonedInjected);
        freeClonedStack(cloned);
        return;
    }
    
    char frame[128];
    snprintf(frame, sizeof(frame), "insertAtBottom(\"%s\")", (*top)->name);
    PushCallStack(frame);
    
    TStack *temp = *top;
    *top = (*top)->next;
    
    TStack *clonedPopped = cloneStack(*top);
    RecordStep("Insert Stack Bottom Popping", TextFormat("Temporarily popping '%s' to insert '%s' below.", temp->name, item->name), NULL, clonedPopped, NULL, -1, item->name);
    trace_insert_at_bottom_stack_rec(top, item);
    
    temp->next = *top;
    *top = temp;
    
    TStack *clonedRestored = cloneStack(*top);
    RecordStep("Insert Stack Bottom Restoring", TextFormat("Restoring popped item '%s' back onto top of stack.", temp->name), NULL, clonedRestored, NULL, -1, temp->name);
    PopCallStack();
    freeClonedStack(clonedPopped);
    freeClonedStack(clonedRestored);
    freeClonedStack(cloned);
}

static void trace_reverse_stack_recursive_rec(TStack **top) {
    TStack *cloned = cloneStack(*top);
    if (*top == NULL) {
        PushCallStack("reverse(NULL)");
        RecordStep("Stack Reversal Base Case", "Empty stack reached.", NULL, cloned, NULL, -1, NULL);
        PopCallStack();
        freeClonedStack(cloned);
        return;
    }
    
    char frame[128];
    snprintf(frame, sizeof(frame), "reverse(\"%s\")", (*top)->name);
    PushCallStack(frame);
    
    TStack *temp = *top;
    *top = (*top)->next;
    
    TStack *clonedPopped = cloneStack(*top);
    RecordStep("Stack Reversal Popping Element", TextFormat("Popped '%s' off stack top. Reversing rest of stack.", temp->name), NULL, clonedPopped, NULL, -1, temp->name);
    trace_reverse_stack_recursive_rec(top);
    
    TStack *clonedSubReversed = cloneStack(*top);
    RecordStep("Stack Reversal Inserting to Bottom", TextFormat("Inserting '%s' back to the bottom of reversed stack.", temp->name), NULL, clonedSubReversed, NULL, -1, temp->name);
    temp->next = NULL;
    trace_insert_at_bottom_stack_rec(top, temp);
    
    PopCallStack();
}

void trace_reverse_stack_recursive(TStack **top) {
    if (top == NULL || *top == NULL) return;
    StartTrace("Recursive Stack Reversal", 3);
    trace_reverse_stack_recursive_rec(top);
    EndTrace();
}

static int trace_tree_height_recursive_rec(TTree *root, TTree *node) {
    TTree *cloned = cloneTree(root);
    if (node == NULL) {
        PushCallStack("height(NULL)");
        RecordStep("Height Base Case", "Empty sub-tree has height 0.", NULL, NULL, cloned, -1, NULL);
        PopCallStack();
        freeClonedTree(cloned);
        return 0;
    }
    
    char frame[128];
    snprintf(frame, sizeof(frame), "height(\"%s\")", node->name);
    PushCallStack(frame);
    
    RecordStep("Height Traversal Left", TextFormat("Evaluating left child height for node '%s'.", node->name), NULL, NULL, cloned, -1, node->name);
    int left_h = trace_tree_height_recursive_rec(root, node->left);
    
    RecordStep("Height Traversal Right", TextFormat("Evaluating right child height for node '%s'.", node->name), NULL, NULL, cloned, -1, node->name);
    int right_h = trace_tree_height_recursive_rec(root, node->right);
    
    int self_h = (left_h > right_h ? left_h : right_h) + 1;
    RecordStep("Height Evaluation Return", TextFormat("Node '%s' returns: max(left:%d, right:%d) + 1 = %d", node->name, left_h, right_h, self_h), NULL, NULL, cloned, -1, node->name);
    
    PopCallStack();
    freeClonedTree(cloned);
    return self_h;
}

int trace_tree_height_recursive(TTree *root) {
    StartTrace("Recursive Tree Height", 4);
    int h = trace_tree_height_recursive_rec(root, root);
    EndTrace();
    return h;
}

static int trace_is_balanced_recursive_check(TTree *root, TTree *node, bool *is_bal) {
    TTree *cloned = cloneTree(root);
    if (node == NULL) {
        PushCallStack("checkBalance(NULL)");
        RecordStep("Balance Base Case", "NULL subtree is balanced with height 0.", NULL, NULL, cloned, -1, NULL);
        PopCallStack();
        freeClonedTree(cloned);
        return 0;
    }
    
    char frame[128];
    snprintf(frame, sizeof(frame), "checkBalance(\"%s\")", node->name);
    PushCallStack(frame);
    
    RecordStep("Checking Balance Left", TextFormat("Recurse Left child for '%s'.", node->name), NULL, NULL, cloned, -1, node->name);
    int lh = trace_is_balanced_recursive_check(root, node->left, is_bal);
    
    RecordStep("Checking Balance Right", TextFormat("Recurse Right child for '%s'.", node->name), NULL, NULL, cloned, -1, node->name);
    int rh = trace_is_balanced_recursive_check(root, node->right, is_bal);
    
    int diff = abs(lh - rh);
    if (diff > 1) {
        *is_bal = false;
        RecordStep("Unbalance Detected!", TextFormat("Node '%s' height diff > 1 (|lh:%d - rh:%d| = %d). Marked Unbalanced!", node->name, lh, rh, diff), NULL, NULL, cloned, -1, node->name);
    } else {
        RecordStep("Balanced Subtree Verified", TextFormat("Node '%s' height diff is balanced (|lh:%d - rh:%d| = %d).", node->name, lh, rh, diff), NULL, NULL, cloned, -1, node->name);
    }
    
    PopCallStack();
    freeClonedTree(cloned);
    return (lh > rh ? lh : rh) + 1;
}

bool trace_is_balanced_recursive(TTree *root) {
    StartTrace("Recursive Balance Check", 4);
    bool is_bal = true;
    trace_is_balanced_recursive_check(root, root, &is_bal);
    EndTrace();
    return is_bal;
}



