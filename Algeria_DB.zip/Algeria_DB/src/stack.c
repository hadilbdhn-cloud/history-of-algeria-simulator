#include "../include/stack.h"
#include "../include/gui.h"
#include "../include/linked_list.h"
#include "../include/utils.h"
#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

TStack* createStackNode(const char *name, const char *definition, Date dob, Date dod) {
    TStack *s = (TStack*)malloc(sizeof(TStack));
    if (s) {
        strncpy(s->name, name?name:"", 99); s->name[99]='\0';
        strncpy(s->definition, definition?definition:"", 499); s->definition[499]='\0';
        s->dob = dob; s->dod = dod; s->next = NULL;
    }
    return s;
}

void push(TStack **top, const char *name, const char *definition, Date dob, Date dod) {
    if(!top) return;
    TStack *s = createStackNode(name, definition, dob, dod);
    s->next = *top;
    *top = s;
}

TStack* pop(TStack **top) {
    if(!top || !*top) return NULL;
    TStack *t = *top;
    *top = (*top)->next;
    return t;
}

TStack* peek(TStack *top) { return top; }
bool isStackEmpty(TStack *top) { return top == NULL; }
int stackSize(TStack *top) { int c=0; while(top){c++;top=top->next;} return c; }
void displayStack(TStack *top) { 
    if(!top){ gui_printf("Stack is empty."); return; }
    while(top){ gui_printf("Stack Item: %s", top->name); top=top->next; } 
}

void reverseStack(TStack **top) {
    if(!top || !*top) return;
    TStack *prev = NULL, *cur = *top, *next = NULL;
    while(cur) {
        next = cur->next;
        cur->next = prev;
        prev = cur;
        cur = next;
    }
    *top = prev;
}

void sortStack(TStack **top) {
    if(!top || !*top) return;
    TStack *res = NULL;
    while(*top) {
        TStack *tmp = pop(top);
        while(res && strcmp(res->name, tmp->name) > 0) {
            TStack *back = pop(&res);
            push(top, back->name, back->definition, back->dob, back->dod);
            free(back);
        }
        push(&res, tmp->name, tmp->definition, tmp->dob, tmp->dod);
        free(tmp);
    }
    *top = res;
}

TStack* searchStack(TStack *top, const char *name) {
    while(top){ if(strcmp(top->name,name)==0) return top; top=top->next; } 
    return NULL;
}

TStack* toStack(TList *merged) {
    TStack *stk = NULL;
    while(merged) {
        push(&stk, merged->name, merged->definition, merged->dob, merged->dod);
        merged = merged->next;
    }
    return stk;
}

TStack* sortNameStack(TStack *s) {
    sortStack(&s);
    
    gui_printf("--- Stack Personalities Sorted Alphabetically ---");
    if (!s) {
        gui_printf("Stack is empty.");
        return NULL;
    }
    
    int index = 1;
    TStack *curr = s;
    while (curr) {
        gui_printf("[%d] %s (%d - %d)", index++, curr->name, curr->dob.year, curr->dod.year);
        gui_printf("    Def: %s", curr->definition);
        curr = curr->next;
    }
    gui_printf("-------------------------------------------------");
    
    return s;
}

TStack* deleteName(TStack *stk, char *name) {
    TStack *temp = NULL;
    while(stk) {
        TStack *node = pop(&stk);
        if(strcmp(node->name, name) != 0) push(&temp, node->name, node->definition, node->dob, node->dod);
        free(node);
    }
    while(temp) {
        TStack *node = pop(&temp);
        push(&stk, node->name, node->definition, node->dob, node->dod);
        free(node);
    }
    return stk;
}

TStack* updateStack_v2(TStack *stk, char *name, char *def, char *DoB, char *DoD) {
    TStack *cur = searchStack(stk, name);
    if(cur) {
        if(def && def[0]) strncpy(cur->definition, def, 499);
        if(DoB && DoB[0]) sscanf(DoB, "%d", &cur->dob.year);
        if(DoD && DoD[0]) sscanf(DoD, "%d", &cur->dod.year);
    }
    return stk;
}

TStack* definitionStack(TStack *stk) {
    TStack *sorted = NULL;
    while(stk) {
        TStack *tmp = pop(&stk);
        while(sorted && countWords(sorted->definition) < countWords(tmp->definition)) {
            TStack *back = pop(&sorted);
            push(&stk, back->name, back->definition, back->dob, back->dod); free(back);
        }
        push(&sorted, tmp->name, tmp->definition, tmp->dob, tmp->dod); free(tmp);
    }
    return sorted;
}


TStack* recRevStack(TStack *stk) {
    if(!stk || !stk->next) return stk;
    TStack *rev = recRevStack(stk->next);
    TStack *curr = rev;
    while(curr->next) curr = curr->next;
    curr->next = stk;
    stk->next = NULL;
    return rev;
}

/* Stubs */
void displayPersonalitiesStack(TStack *top) { displayStack(top); }
TStack* getInfoPersonality(TStack *stk, char *name) {
    if (!stk) {
        gui_printf("Stack is empty. No personalities available.");
        return NULL;
    }
    if (!name || name[0] == '\0') {
        gui_printf("ERR: Search name is empty.");
        return NULL;
    }
    
    char lowerName[128];
    int qLen = 0;
    for (; name[qLen] && qLen < 127; qLen++) {
        lowerName[qLen] = tolower((unsigned char)name[qLen]);
    }
    lowerName[qLen] = '\0';
    
    TStack *curr = stk;
    TStack *foundNode = NULL;
    
    while (curr) {
        char lowerNodeName[128];
        int i;
        for (i = 0; curr->name[i] && i < 127; i++) {
            lowerNodeName[i] = tolower((unsigned char)curr->name[i]);
        }
        lowerNodeName[i] = '\0';
        
        if (strstr(lowerNodeName, lowerName)) {
            foundNode = curr;
            break;
        }
        curr = curr->next;
    }
    
    if (foundNode) {
        int age = foundNode->dod.year - foundNode->dob.year;
        gui_printf("--- Historical Biography Card ---");
        gui_printf("Name      : %s", foundNode->name);
        gui_printf("Lifespan  : %02d/%02d/%04d to %02d/%02d/%04d", 
                   foundNode->dob.day, foundNode->dob.month, foundNode->dob.year,
                   foundNode->dod.day, foundNode->dod.month, foundNode->dod.year);
        gui_printf("Age       : %d years", age > 0 ? age : 0);
        gui_printf("Details   : %s", foundNode->definition);
        gui_printf("Word Count: %d words", countWords(foundNode->definition));
        return foundNode;
    } else {
        gui_printf("Personality \"%s\" not found in stack.", name);
        return NULL;
    }
}

TQueue* stackToQueue(TStack *stk) {
    TQueue *q = (TQueue*)malloc(sizeof(TQueue));
    initQueue(q);
    sortStack(&stk);
    while (stk) {
        TStack *node = pop(&stk);
        enqueue(q, node->name, node->definition, node->dob, node->dod);
        free(node);
    }
    return q;
}

TList* stackToList(TStack *stk) {
    TList *head = NULL;
    sortStack(&stk);
    while (stk) {
        TStack *node = pop(&stk);
        TList *n = createNode(node->name, node->definition, node->dob, node->dod);
        insertEnd(&head, n);
        free(node);
    }
    return head;
}

TStack* addNameStack(TStack *stk, char *name, char *definition, char *DoB, char *DoD) {
    Date dob = {0,0,0}, dod = {0,0,0};
    sscanf(DoB, "%d/%d/%d", &dob.day, &dob.month, &dob.year);
    sscanf(DoD, "%d/%d/%d", &dod.day, &dod.month, &dod.year);
    push(&stk, name, definition, dob, dod);
    sortStack(&stk);
    return stk;
}

TStack* pronunciationStack(TStack *stk) {
    TStack *shortS = NULL, *longS = NULL;
    while (stk) {
        TStack *node = pop(&stk);
        if (strlen(node->definition) < 50) push(&shortS, node->name, node->definition, node->dob, node->dod);
        else push(&longS, node->name, node->definition, node->dob, node->dod);
        free(node);
    }
    // Return long events, display short
    displayStack(shortS);
    return longS;
}

void continuousSearch(TStack *stk, const char *query) {
    if (!stk) {
        gui_printf("Stack is empty. Cannot search.");
        return;
    }
    if (!query || query[0] == '\0') {
        gui_printf("ERR: Search keyword is empty.");
        return;
    }
    
    char lowerQuery[128];
    int qLen = 0;
    for (; query[qLen] && qLen < 127; qLen++) {
        lowerQuery[qLen] = tolower((unsigned char)query[qLen]);
    }
    lowerQuery[qLen] = '\0';
    
    gui_printf("--- Continuous Search for \"%s\" ---", query);
    int matchCount = 0;
    TStack *curr = stk;
    
    while (curr) {
        char lowerName[128];
        int i;
        for (i = 0; curr->name[i] && i < 127; i++) {
            lowerName[i] = tolower((unsigned char)curr->name[i]);
        }
        lowerName[i] = '\0';
        
        char lowerDef[512];
        int j;
        for (j = 0; curr->definition[j] && j < 511; j++) {
            lowerDef[j] = tolower((unsigned char)curr->definition[j]);
        }
        lowerDef[j] = '\0';
        
        if (strstr(lowerName, lowerQuery) || strstr(lowerDef, lowerQuery)) {
            matchCount++;
            int age = curr->dod.year - curr->dob.year;
            gui_printf("[%d] Match: %s", matchCount, curr->name);
            gui_printf("    Lifespan: %02d/%02d/%d to %02d/%02d/%d (lived %d years)", 
                       curr->dob.day, curr->dob.month, curr->dob.year,
                       curr->dod.day, curr->dod.month, curr->dod.year,
                       age > 0 ? age : 0);
            gui_printf("    Definition: %s", curr->definition);
        }
        curr = curr->next;
    }
    
    if (matchCount == 0) {
        gui_printf("No personalities found matching \"%s\".", query);
    } else {
        gui_printf("----------------------------------------");
        gui_printf("Continuous Search completed: %d matches.", matchCount);
    }
}

bool isPersonalityKilled(char *word) {
    if (!word || word[0] == '\0') {
        gui_printf("ERR: Definition text is empty.");
        return false;
    }
    
    char lower[512];
    int i;
    for (i = 0; word[i] && i < 511; i++) {
        lower[i] = tolower((unsigned char)word[i]);
    }
    lower[i] = '\0';
    
    const char *keywords[] = {
        "kill", "tue", "martyr", "assassin", "execute", 
        "guillotine", "fusill", "tortur", "mourut", "mort",
        "hang", "pendu", "battle", "guerre", "combat", "bataille"
    };
    int num_keywords = sizeof(keywords) / sizeof(keywords[0]);
    
    gui_printf("--- Violent Death / Martyrdom Analysis ---");
    gui_printf("Analyzing: \"%s\"", word);
    
    char matched[128] = "";
    bool detected = false;
    
    for (int k = 0; k < num_keywords; k++) {
        if (strstr(lower, keywords[k])) {
            detected = true;
            if (strlen(matched) > 0) {
                strcat(matched, ", ");
            }
            strcat(matched, keywords[k]);
        }
    }
    
    if (detected) {
        gui_printf("Result: MARTYRDOM / VIOLENT DEATH DETECTED");
        gui_printf("Trigger keywords matched: [%s]", matched);
        return true;
    } else {
        gui_printf("Result: No violent death or martyrdom keywords found.");
        return false;
    }
}

char* getSmallest(TStack *stk) {
    if (!stk) {
        gui_printf("Stack is empty. No smallest definition found.");
        return NULL;
    }
    
    TStack *smallestNode = stk;
    TStack *curr = stk;
    while (curr) {
        if (strlen(curr->definition) < strlen(smallestNode->definition)) {
            smallestNode = curr;
        }
        curr = curr->next;
    }
    
    gui_printf("--- Personality with Shortest Definition ---");
    gui_printf("Name: %s", smallestNode->name);
    gui_printf("Lifespan: %02d/%02d/%04d - %02d/%02d/%04d", 
               smallestNode->dob.day, smallestNode->dob.month, smallestNode->dob.year,
               smallestNode->dod.day, smallestNode->dod.month, smallestNode->dod.year);
    gui_printf("Def Length: %d chars", (int)strlen(smallestNode->definition));
    gui_printf("Definition: %s", smallestNode->definition);
    
    return smallestNode->definition;
}