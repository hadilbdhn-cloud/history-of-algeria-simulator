#include "../include/recursion.h"
#include "../include/stack.h"
#include "../include/linked_list.h"
#include "../include/utils.h"

#include "../include/gui.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


/* ── STRINGS ─────────────────────────────────────────────── */
int stringLength(const char *str) { return (str && *str) ? 1 + stringLength(str + 1) : 0; }

void reverseStringRecursive(char *str, int left, int right) {
    if (left >= right) return;
    char t = str[left]; str[left] = str[right]; str[right] = t;
    reverseStringRecursive(str, left + 1, right - 1);
}
void reverseString(char *str) { if(str) reverseStringRecursive(str, 0, strlen(str)-1); }

bool isPalindromeString(const char *str) {
    int l = strlen(str);
    for(int i=0; i<l/2; i++) if(str[i] != str[l-1-i]) return false;
    return true;
}

void removeChar(char *str, char ch) {
    int i, j;
    for (i = j = 0; str[i]; i++) if (str[i] != ch) str[j++] = str[i];
    str[j] = '\0';
}

char* replaceChar(char *str, char oldChar, char newChar) {
    for (int i = 0; str[i]; i++) if (str[i] == oldChar) str[i] = newChar;
    return str;
}


/* ── MATH ────────────────────────────────────────────────── */

int factorial(int n) { return (n <= 1) ? 1 : n * factorial(n - 1); }
int fibonacci(int n) { return (n <= 1) ? n : fibonacci(n - 1) + fibonacci(n - 2); }
int gcd(int a, int b) { return (b == 0) ? a : gcd(b, a % b); }
int power(int a, int b) { return (b == 0) ? 1 : a * power(a, b - 1); }
int sumOfDigits(int n) { return (n == 0) ? 0 : (n % 10) + sumOfDigits(n / 10); }

int reverseNumberRec(int n, int rev) {
    if (n == 0) return rev;
    return reverseNumberRec(n / 10, rev * 10 + (n % 10));
}
int reverseNumber(int n) { return reverseNumberRec(n, 0); }

bool isArmstrong(int n) {
    int sum = 0, temp = n, d = 0;
    while(temp){ d++; temp/=10; }
    temp = n;
    while(temp){ sum += power(temp%10, d); temp/=10; }
    return sum == n;
}

bool isPrimeRec(int n, int i) {
    if (n <= 2) return n == 2;
    if (n % i == 0) return false;
    if (i * i > n) return true;
    return isPrimeRec(n, i + 1);
}
bool isPrime(int n) { return isPrimeRec(n, 2); }

void towerOfHanoi(int n, char from, char to, char aux) {
    if (n == 1) { gui_printf("Move disk 1 from %c to %c", from, to); return; }
    towerOfHanoi(n - 1, from, aux, to);
    gui_printf("Move disk %d from %c to %c", n, from, to);
    towerOfHanoi(n - 1, aux, to, from);
}

/* ── DS RECURSIVE ────────────────────────────────────────── */
void printListRecursive(TList *head) {
    if (!head) return;
    gui_printf("Item: %s", head->name);
    printListRecursive(head->next);
}

int countNodesRecursive(TList *head) {
    return head ? 1 + countNodesRecursive(head->next) : 0;
}

TList* searchRecursive(TList *head, const char *name) {
    if (!head || strcmp(head->name, name) == 0) return head;
    return searchRecursive(head->next, name);
}

void reverseListRecursive(TList **head) {
    if (!head || !*head || !(*head)->next) return;
    TList *first = *head;
    TList *rest = first->next;
    reverseListRecursive(&rest);
    
    first->next->next = first;
    first->prev = first->next; // Fix bidirectional
    first->next = NULL;
    
    *head = rest;
    if (*head) (*head)->prev = NULL;
}


void printStackRecursive(TStack *top) {
    if (!top) return;
    gui_printf("Stack: %s", top->name);
    printStackRecursive(top->next);
}

int countStackNodesRecursive(TStack *top) {
    return top ? 1 + countStackNodesRecursive(top->next) : 0;
}

void reverseStackRecursive(TStack **top) {
    if (!top || !*top) return;
    TStack *tmp = pop(top);
    reverseStackRecursive(top);
    // Push at bottom (simplified)
    TStack *stk = *top;
    if(!stk) *top = tmp;
    else {
        while(stk->next) stk = stk->next;
        stk->next = tmp;
        tmp->next = NULL;
    }
}

void inorderRecursive(TTree *root) {
    if (!root) return;
    inorderRecursive(root->left);
    gui_printf("BST: %s", root->name);
    inorderRecursive(root->right);
}

int heightRecursive(TTree *root) {
    if (!root) return 0;
    int lh = heightRecursive(root->left);
    int rh = heightRecursive(root->right);
    return 1 + (lh > rh ? lh : rh);
}

int countTreeNodesRecursive(TTree *root) {
    return root ? 1 + countTreeNodesRecursive(root->left) + countTreeNodesRecursive(root->right) : 0;
}

TTree* mirrorRecursive(TTree *root) {
    if (!root) return NULL;
    TTree *tmp = root->left;
    root->left = mirrorRecursive(root->right);
    root->right = mirrorRecursive(tmp);
    return root;
}

bool isBalancedRecursive(TTree *root) { return true; }

/* ── PERMUTATIONS ────────────────────────────────────────── */
void swap(char *x, char *y) { char t = *x; *x = *y; *y = t; }
void permuteRec(char *str, int l, int r) {
    if (l == r) gui_printf("Perm: %s\n", str);

    else {
        for (int i = l; i <= r; i++) {
            swap(str + l, str + i);
            permuteRec(str, l + 1, r);
            swap(str + l, str + i);
        }
    }
}
void namePermutation(char *name) { if(name) permuteRec(name, 0, strlen(name)-1); }

void subseqRec(char *word, int index, char *res, int res_i) {
    if (index == (int)strlen(word)) { res[res_i] = '\0'; gui_printf("Subseq: %s\n", res); return; }

    subseqRec(word, index + 1, res, res_i);
    res[res_i] = word[index];
    subseqRec(word, index + 1, res, res_i + 1);
}
void subseqName(char *word) { if(word){ char res[100]; subseqRec(word, 0, res, 0); } }

bool isPalindromeWord(char *word) { return isPalindromeString(word); }

int countOccurence(FILE *f, char *name) {
    if (!f) return 0;
    char line[1024];
    if (fgets(line, sizeof(line), f)) {
        int count = strstr(line, name) ? 1 : 0;
        return count + countOccurence(f, name);
    }
    return 0;
}

// Longest Common Subsequence for year strings
int lcs(char *s1, char *s2, int m, int n) {
    if (m == 0 || n == 0) return 0;
    if (s1[m-1] == s2[n-1]) return 1 + lcs(s1, s2, m-1, n-1);
    int a = lcs(s1, s2, m, n-1);
    int b = lcs(s1, s2, m-1, n);
    return (a > b) ? a : b;
}

void longestSubyear(char *date1, char *date2) {
    int len = lcs(date1, date2, strlen(date1), strlen(date2));
    gui_printf("Longest Common Subsequence length: %d", len);
}

int distinctSubseqWord(char *s) {
    // Simplified recursive count: 2^n for distinct characters
    if (!s || !*s) return 1;
    return 2 * distinctSubseqWord(s + 1);
}