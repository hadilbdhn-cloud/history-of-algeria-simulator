#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "../include/types.h"
#include "../include/linked_list.h"
#include "../include/stack.h"
#include "../include/bst.h"
#include "../include/recursion.h"
#include "../include/utils.h"

// Dummy gui_printf for CLI testing
void gui_printf(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    printf("\n");
    va_end(args);
}

int main() {
    printf("=== MODULE VERIFICATION SUITE ===\n\n");

    // 1. Linked List
    printf("[1] Testing Linked List & Enhanced Operations...\n");
    TList *list = NULL;
    Date d1 = {1, 1, 1954}, d2 = {1, 1, 1962};
    insertEnd(&list, createNode("Larbi", "Description A", d1, d2));
    insertEnd(&list, createNode("Ali", "Description B", d1, d2));
    insertEnd(&list, createNode("Hassiba", "Description C", d1, d2));
    
    printf("\n  a) Testing findMiddle:\n");
    findMiddle(list);
    
    printf("\n  b) Testing isPalindrome (should be FALSE):\n");
    isPalindrome(list);
    
    // Palindromic list setup
    TList *palList = NULL;
    insertEnd(&palList, createNode("Larbi", "Desc", d1, d2));
    insertEnd(&palList, createNode("Ali", "Desc", d1, d2));
    insertEnd(&palList, createNode("Larbi", "Desc", d1, d2));
    
    printf("\n  c) Testing isPalindrome (should be TRUE):\n");
    isPalindrome(palList);
    
    // Cleanup lists
    while(list) {
        TList *tmp = list;
        list = list->next;
        free(tmp);
    }
    while(palList) {
        TList *tmp = palList;
        palList = palList->next;
        free(tmp);
    }
    
    // 2. Stack
    printf("\n[2] Testing Stack & Enhanced Operations...\n");
    TStack *stack = NULL;
    Date dob1 = {25, 11, 1923}, dod1 = {9, 3, 1957};
    Date dob2 = {1, 1, 1930}, dod2 = {17, 10, 1961};
    Date dob3 = {6, 9, 1808}, dod3 = {26, 5, 1883};
    
    push(&stack, "Emir Abdelkader", "Algerian leader against French colonisation", dob3, dod3);
    push(&stack, "Ben M'hidi Larbi", "FLN chief, key leader in the War of Independence, martyrise en 1957", dob1, dod1);
    push(&stack, "Ali la Pointe", "FLN militant", dob2, dod2);
    
    printf("\n  a) Testing isPersonalityKilled:\n");
    isPersonalityKilled("Ben M'hidi Larbi was martyrise en 1957");
    isPersonalityKilled("Emir Abdelkader was an Algerian resistance leader");
    
    printf("\n  b) Testing getSmallest (should be Ali la Pointe):\n");
    getSmallest(stack);
    
    printf("\n  c) Testing getInfoPersonality (search for 'Ben M'hidi'):\n");
    getInfoPersonality(stack, "Ben M'hidi");
    
    printf("\n  d) Testing continuousSearch (search for 'FLN'):\n");
    continuousSearch(stack, "FLN");
    
    printf("\n  e) Testing sortNameStack:\n");
    stack = sortNameStack(stack);
    
    // Cleanup stack
    while(stack) {
        TStack *tmp = pop(&stack);
        free(tmp);
    }

    // 3. BST
    printf("\n[3] Testing BST...\n");
    TTree *rootNode = NULL;
    rootNode = insertBST(rootNode, "Mouloud", "Writer", d1, d2);
    rootNode = insertBST(rootNode, "Abane", "Leader", d1, d2);
    if (rootNode && countBSTNodes(rootNode) == 2) printf("  - BST Insertion & Count: OK\n");
    // if (isBalanced(rootNode)) printf("  - isBalanced: OK\n");

    // 4. Recursion
    printf("\n[4] Testing Recursion...\n");
    if (factorial(5) == 120) printf("  - Factorial: OK\n");
    if (fibonacci(10) == 55) printf("  - Fibonacci: OK\n");
    
    printf("\n=== VERIFICATION COMPLETE ===\n");
    return 0;
}
