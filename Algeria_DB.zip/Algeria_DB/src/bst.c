#include "../include/bst.h"
#include "../include/gui.h"
#include "../include/stack.h"
#include <stdio.h>

#include <stdlib.h>
#include <string.h>

TTree* createBSTNode(const char *name, const char *definition, Date dob, Date dod) {
    TTree *t = (TTree*)malloc(sizeof(TTree));
    if (t) {
        strncpy(t->name, name?name:"", 99); t->name[99]='\0';
        strncpy(t->definition, definition?definition:"", 499); t->definition[499]='\0';
        t->dob = dob; t->dod = dod; t->left = t->right = NULL;
    }
    return t;
}

TTree* insertBST(TTree *root, const char *name, const char *definition, Date dob, Date dod) {
    if (!root) return createBSTNode(name, definition, dob, dod);
    if (strcmp(name, root->name) < 0) root->left = insertBST(root->left, name, definition, dob, dod);
    else if (strcmp(name, root->name) > 0) root->right = insertBST(root->right, name, definition, dob, dod);
    return root;
}

TTree* deleteBSTNode(TTree *root, const char *name) {
    if (!root) return NULL;
    if (strcmp(name, root->name) < 0) root->left = deleteBSTNode(root->left, name);
    else if (strcmp(name, root->name) > 0) root->right = deleteBSTNode(root->right, name);
    else {
        if (!root->left) { TTree *tmp = root->right; free(root); return tmp; }
        else if (!root->right) { TTree *tmp = root->left; free(root); return tmp; }
        TTree *tmp = root->right;
        while (tmp && tmp->left) tmp = tmp->left;
        strcpy(root->name, tmp->name);
        strcpy(root->definition, tmp->definition);
        root->dob = tmp->dob; root->dod = tmp->dod;
        root->right = deleteBSTNode(root->right, tmp->name);
    }
    return root;
}

TTree* searchBST(TTree *root, const char *name) {
    if (!root || strcmp(name, root->name) == 0) return root;
    if (strcmp(name, root->name) < 0) return searchBST(root->left, name);
    return searchBST(root->right, name);
}

void inorderTraversal(TTree *root) {
    if (!root) return;
    inorderTraversal(root->left);
    gui_printf("BST: %s", root->name);
    inorderTraversal(root->right);
}


void preorderTraversal(TTree *root) {
    if (!root) return;
    gui_printf("BST: %s", root->name);
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}


void postorderTraversal(TTree *root) {
    if (!root) return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    gui_printf("BST: %s", root->name);
}


TTree* traversalBSTinOrder(TTree *tr) { inorderTraversal(tr); return tr; }
TTree* traversalBSTpreOrder(TTree *tr) { preorderTraversal(tr); return tr; }
TTree* traversalBSTpostOrder(TTree *tr) { postorderTraversal(tr); return tr; }


int treeHeight(TTree *root) {
    if (!root) return 0;
    int lh = treeHeight(root->left);
    int rh = treeHeight(root->right);
    return 1 + (lh > rh ? lh : rh);
}

TTree* mirrorBST(TTree *root) {
    if (!root) return NULL;
    TTree *tmp = root->left;
    root->left = mirrorBST(root->right);
    root->right = mirrorBST(tmp);
    return root;
}

TTree* lowestCommonAncestor(TTree *tr, char *word1, char *word2) {
    if (!tr) return NULL;
    if (strcmp(tr->name, word1) > 0 && strcmp(tr->name, word2) > 0) return lowestCommonAncestor(tr->left, word1, word2);
    if (strcmp(tr->name, word1) < 0 && strcmp(tr->name, word2) < 0) return lowestCommonAncestor(tr->right, word1, word2);
    return tr;
}

TTree* updateNameBST(TTree *tr, char *name, char *s, char *DoB, char *DoD) {
    TTree *node = searchBST(tr, name);
    if (node) {
        if (s && s[0]) strncpy(node->definition, s, 499);
        if (DoB && DoB[0]) sscanf(DoB, "%d", &node->dob.year);
        if (DoD && DoD[0]) sscanf(DoD, "%d", &node->dod.year);
    }
    return tr;
}

/* Stubs */
void levelOrderTraversal(TTree *root) { inorderTraversal(root); }
int countBSTNodes(TTree *root) { return root ? 1 + countBSTNodes(root->left) + countBSTNodes(root->right) : 0; }
int countLeafNodes(TTree *root) {
    if (!root) return 0;
    if (!root->left && !root->right) return 1;
    return countLeafNodes(root->left) + countLeafNodes(root->right);
}
TTree* findMin(TTree *root) { while(root && root->left) root=root->left; return root; }
TTree* findMax(TTree *root) { while(root && root->right) root=root->right; return root; }
bool isBalanced(TTree *root) {
    if (!root) return true;
    int lh = treeHeight(root->left), rh = treeHeight(root->right);
    return (abs(lh-rh)<=1 && isBalanced(root->left) && isBalanced(root->right));
}
void printBST(TTree *root, int space) { inorderTraversal(root); }

TTree* toTree(TStack *stk) { TTree *root = NULL; while(stk){ root = insertBST(root, stk->name, stk->definition, stk->dob, stk->dod); stk=stk->next; } return root; }
TTree* convertListToBST(TList *head) { TTree *root = NULL; while(head){ root = insertBST(root, head->name, head->definition, head->dob, head->dod); head=head->next; } return root; }
TTree* deleteNameBST(TTree *tr, char *name) { return deleteBSTNode(tr, name); }

TTree* fillTree(FILE *f) {
    if (!f) return NULL;
    TTree *root = NULL;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char *name = strtok(line, "=");
        char *def = strtok(NULL, ":");
        char *yearStr = strtok(NULL, ":");
        if (name && def && yearStr) {
            Date dob = {1, 1, atoi(yearStr)};
            root = insertBST(root, name, def, dob, (Date){1,1,0});
        }
    }
    return root;
}

static void treeToStack(TTree *tr, TStack **stk) {
    if (!tr) return;
    treeToStack(tr->left, stk);
    push(stk, tr->name, tr->definition, tr->dob, tr->dod);
    treeToStack(tr->right, stk);
}

TStack* addNameBST(TTree *tr, char *name, char *DoB, char *DoD) {
    Date dob = {0,0,0}, dod = {0,0,0};
    sscanf(DoB, "%d/%d/%d", &dob.day, &dob.month, &dob.year);
    sscanf(DoD, "%d/%d/%d", &dod.day, &dod.month, &dod.year);
    tr = insertBST(tr, name, "Added via BST", dob, dod);
    TStack *stk = NULL;
    treeToStack(tr, &stk);
    return stk;
}


void heightSizeBST(TTree *tr) {
    gui_printf("Height: %d, Size: %d", treeHeight(tr), countBSTNodes(tr));
}

int countNodesRange(TTree *tr, int l, int h) {
    if (!tr) return 0;
    int count = (tr->dob.year >= l && tr->dob.year <= h) ? 1 : 0;
    return count + countNodesRange(tr->left, l, h) + countNodesRange(tr->right, l, h);
}

TTree* inOrderSuccessor(TTree *tr, char *word) {
    TTree *curr = searchBST(tr, word);
    if (!curr) return NULL;
    if (curr->right) return findMin(curr->right);
    TTree *succ = NULL, *ancestor = tr;
    while (ancestor != curr) {
        if (strcmp(curr->name, ancestor->name) < 0) { succ = ancestor; ancestor = ancestor->left; }
        else ancestor = ancestor->right;
    }
    return succ;
}

bool isBalancedBST(TTree *tr) {
    if (!tr) return true;
    int lh = treeHeight(tr->left);
    int rh = treeHeight(tr->right);
    if (abs(lh - rh) <= 1 && isBalancedBST(tr->left) && isBalancedBST(tr->right)) return true;
    return false;
}

static void treeToArray(TTree *tr, TTree **arr, int *index) {
    if (!tr) return;
    treeToArray(tr->left, arr, index);
    arr[(*index)++] = tr;
    treeToArray(tr->right, arr, index);
}

static TTree* buildBalancedBSTFromArr(TTree **arr, int start, int end) {
    if (start > end) return NULL;
    int mid = (start + end) / 2;
    TTree *root = arr[mid];
    root->left = buildBalancedBSTFromArr(arr, start, mid - 1);
    root->right = buildBalancedBSTFromArr(arr, mid + 1, end);
    return root;
}

TTree* BTSMerge(TTree *tr1, TTree *tr2) {
    int n1 = countBSTNodes(tr1), n2 = countBSTNodes(tr2);
    TTree **arr = (TTree**)malloc(sizeof(TTree*) * (n1 + n2));
    int idx = 0;
    treeToArray(tr1, arr, &idx);
    treeToArray(tr2, arr, &idx);
    // Sort array by name
    for (int i = 0; i < idx - 1; i++) {
        for (int j = i + 1; j < idx; j++) {
            if (strcmp(arr[i]->name, arr[j]->name) > 0) {
                TTree *t = arr[i]; arr[i] = arr[j]; arr[j] = t;
            }
        }
    }
    TTree *res = buildBalancedBSTFromArr(arr, 0, idx - 1);
    free(arr);
    return res;
}

void destroyBST(TTree *root) { if(!root) return; destroyBST(root->left); destroyBST(root->right); free(root); }