#include "../include/linked_list.h"
#include "../include/utils.h"
#include "../include/gui.h"
#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include <ctype.h>


/* ── CORE LL ─────────────────────────────────────────────── */

TList* createNode(const char *name, const char *definition, Date dob, Date dod) {
    TList *node = (TList*)malloc(sizeof(TList));
    if (node) {
        strncpy(node->name, name ? name : "", sizeof(node->name)-1);
        node->name[sizeof(node->name)-1] = '\0';
        strncpy(node->definition, definition ? definition : "", sizeof(node->definition)-1);
        node->definition[sizeof(node->definition)-1] = '\0';
        node->dob = dob; node->dod = dod;
        node->next = node->prev = NULL;
    }
    return node;
}

void insertBeginning(TList **head, TList *newNode) {
    if (!head || !newNode) return;
    newNode->next = *head;
    newNode->prev = NULL;
    if (*head) (*head)->prev = newNode;
    *head = newNode;
}

void insertEnd(TList **head, TList *newNode) {
    if (!head || !newNode) return;
    if (!*head) { *head = newNode; return; }
    TList *cur = *head;
    while (cur->next) cur = cur->next;
    cur->next = newNode;
    newNode->prev = cur;
}

void deleteNode(TList **head, const char *name) {
    if (!head || !*head) return;
    TList *cur = *head;
    while (cur) {
        if (strcmp(cur->name, name) == 0) {
            if (cur->prev) cur->prev->next = cur->next;
            else *head = cur->next;
            if (cur->next) cur->next->prev = cur->prev;
            TList *toDel = cur;
            cur = cur->next;
            free(toDel);
            return;
        }
        cur = cur->next;
    }
}


TList* searchNode(TList *head, const char *name) {
    while (head) {
        if (strcmp(head->name, name) == 0) return head;
        head = head->next;
    }
    return NULL;
}

void displayList(TList *head) {
    if (!head) { gui_printf("List is empty."); return; }
    while (head) {
        gui_printf("Name: %s", head->name);
        gui_printf("  - %s", head->definition);
        gui_printf("  - Lifespan: %02d/%02d/%04d to %02d/%02d/%04d", 
               head->dob.day, head->dob.month, head->dob.year,
               head->dod.day, head->dod.month, head->dod.year);
        head = head->next;
    }
}


void displayListReverse(TList *head) {
    if (!head) return;
    while (head->next) head = head->next;
    while (head) {
        gui_printf("Name: %s", head->name);
        head = head->prev;
    }
}


int countNodes(TList *head) {
    int c = 0;
    while (head) { c++; head = head->next; }
    return c;
}

void sortList(TList **head) {
    if (!head || !*head || !(*head)->next) {
        gui_printf("List is empty or has only 1 element. No sorting required.");
        return;
    }
    
    gui_printf("--- Sorting Linked List Alphabetically ---");
    int count = countNodes(*head);
    gui_printf("Sorting %d personalities...", count);
    
    bool swapped;
    TList *ptr1;
    TList *lptr = NULL;
    int passes = 0;
    int swaps = 0;
    
    do {
        swapped = false;
        ptr1 = *head;
        passes++;
        
        while (ptr1->next != lptr) {
            if (strcmp(ptr1->name, ptr1->next->name) > 0) {
                // Swap data
                char tname[100], tdef[500]; Date tdob, tdod;
                strcpy(tname, ptr1->name); strcpy(tdef, ptr1->definition);
                tdob = ptr1->dob; tdod = ptr1->dod;
                
                strcpy(ptr1->name, ptr1->next->name);
                strcpy(ptr1->definition, ptr1->next->definition);
                ptr1->dob = ptr1->next->dob;
                ptr1->dod = ptr1->next->dod;
                
                strcpy(ptr1->next->name, tname);
                strcpy(ptr1->next->definition, tdef);
                ptr1->next->dob = tdob;
                ptr1->next->dod = tdod;
                
                swapped = true;
                swaps++;
                gui_printf("Swap [%d]: Exchanged position of \"%s\" and \"%s\"", 
                           swaps, ptr1->next->name, ptr1->name);
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    } while (swapped);
    
    gui_printf("Sort Completed! Total passes: %d, Total swaps: %d", passes, swaps);
    gui_printf("------------------------------------------");
}

void reverseList(TList **head) {
    if (!head || !*head) {
        gui_printf("List is empty. Cannot reverse.");
        return;
    }
    if (!(*head)->next) {
        gui_printf("List has only 1 element. Reversal trivial.");
        return;
    }
    
    gui_printf("--- Reversing Doubly Linked List ---");
    int count = countNodes(*head);
    gui_printf("Reversing pointers for %d elements...", count);
    
    TList *temp = NULL;
    TList *current = *head;
    int steps = 0;
    
    while (current != NULL) {
        temp = current->prev;
        current->prev = current->next;
        current->next = temp;
        
        steps++;
        gui_printf("Step %d: Swapped prev/next for node \"%s\"", steps, current->name);
        
        if (current->prev == NULL) {
            *head = current; // Found new head
        }
        current = current->prev; // Move to next element (which is now in prev because we swapped)
    }
    
    gui_printf("Success! Linked list reversed. New head is \"%s\".", (*head)->name);
    gui_printf("------------------------------------");
}


TList* rotateList(TList *head, int k) {
    int n = countNodes(head);
    if (n <= 1 || (k % n) == 0) return head;
    k %= n;
    TList *tail = head;
    while (tail->next) tail = tail->next;
    
    // Connect tail to head
    tail->next = head;
    head->prev = tail;
    
    TList *newTail = head;
    for (int i = 0; i < n - k - 1; i++) newTail = newTail->next;
    
    TList *newHead = newTail->next;
    newHead->prev = NULL;
    newTail->next = NULL;
    return newHead;
}

void removeDuplicates(TList *head) {
    while (head) {
        TList *runner = head->next;
        while (runner) {
            if (strcmp(head->name, runner->name) == 0) {
                TList *toDel = runner;
                runner = runner->next;
                if (toDel->prev) toDel->prev->next = toDel->next;
                if (toDel->next) toDel->next->prev = toDel->prev;
                free(toDel);
            } else runner = runner->next;
        }
        head = head->next;
    }
}

/* ── QUEUE ───────────────────────────────────────────────── */
void initQueue(TQueue *q) { q->front = q->rear = NULL; }
void enqueue(TQueue *q, const char *name, const char *def, Date dob, Date dod) {
    TQNode *node = (TQNode*)malloc(sizeof(TQNode));
    strncpy(node->name, name, 99); node->name[99]='\0';
    strncpy(node->definition, def, 499); node->definition[499]='\0';
    node->dob = dob; node->dod = dod; node->next = NULL;
    if (!q->rear) q->front = q->rear = node;
    else { q->rear->next = node; q->rear = node; }
}
TQNode* dequeue(TQueue *q) {
    if (!q->front) return NULL;
    TQNode *t = q->front;
    q->front = q->front->next;
    if (!q->front) q->rear = NULL;
    return t;
}
TQNode* peekQueue(TQueue *q) { return q->front; }
void displayQueue(TQueue *q) {
    TQNode *cur = q->front;
    while (cur) { gui_printf("Q: %s", cur->name); cur = cur->next; }
}


/* ── MODULE 2 HISTORICAL ─────────────────────────────────── */
void addPersonality(TList **head, const char *name, const char *def, Date dob, Date dod) {
    insertEnd(head, createNode(name, def, dob, dod));
}
void displayPersonalities(TList *head) { displayList(head); }
TList* searchPersonality(TList *head, const char *name) { return searchNode(head, name); }

TList* sortWord(TList *syn) { sortList(&syn); return syn; }

TList* sortWord2(TList *syn) {
    if (!syn || !syn->next) return syn;
    bool swapped; TList *p1, *lp = NULL;
    do {
        swapped = false; p1 = syn;
        while (p1->next != lp) {
            if (strlen(p1->name) > strlen(p1->next->name)) {
                char tn[100], td[500]; Date d1, d2;
                strcpy(tn, p1->name); strcpy(td, p1->definition); d1=p1->dob; d2=p1->dod;
                strcpy(p1->name, p1->next->name); strcpy(p1->definition, p1->next->definition); p1->dob=p1->next->dob; p1->dod=p1->next->dod;
                strcpy(p1->next->name, tn); strcpy(p1->next->definition, td); p1->next->dob=d1; p1->next->dod=d2;
                swapped = true;
            }
            p1 = p1->next;
        }
        lp = p1;
    } while (swapped);
    return syn;
}

TList* sortPersonality(TList *syn) {
    if (!syn || !syn->next) return syn;
    bool swapped; TList *p1, *lp = NULL;
    do {
        swapped = false; p1 = syn;
        while (p1->next != lp) {
            if (p1->dob.year > p1->next->dob.year) {
                char tn[100], td[500]; Date d1, d2;
                strcpy(tn, p1->name); strcpy(td, p1->definition); d1=p1->dob; d2=p1->dod;
                strcpy(p1->name, p1->next->name); strcpy(p1->definition, p1->next->definition); p1->dob=p1->next->dob; p1->dod=p1->next->dod;
                strcpy(p1->next->name, tn); strcpy(p1->next->definition, td); p1->next->dob=d1; p1->next->dod=d2;
                swapped = true;
            }
            p1 = p1->next;
        }
        lp = p1;
    } while (swapped);
    return syn;
}

TList* deletepersonality(FILE *f, TList *s, TList *a, char *name) { deleteNode(&s, name); return s; }

TList* getPersonality(FILE *f) {
    if (!f) return NULL;
    TList *head = NULL;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char *name = strtok(line, "=");
        char *def = strtok(NULL, ":");
        if (name && def) {
            TList *n = createNode(name, def, (Date){1,1,0}, (Date){1,1,0});
            insertEnd(&head, n);
        }
    }
    return head;
}

TList* getDatePersonality(FILE *f) {
    if (!f) return NULL;
    TList *head = NULL;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char *name = strtok(line, "=");
        char *def = strtok(NULL, ":");
        char *yearStr = strtok(NULL, ":");
        if (name && def && yearStr) {
            Date dob = {1, 1, atoi(yearStr)};
            TList *n = createNode(name, def, dob, (Date){1,1,0});
            insertEnd(&head, n);
        }
    }
    return head;
}

void getInfoByDates_v2(TList *s, TList *DoB) {
    while (s) {
        TList *cur = DoB;
        while (cur) {
            if (s->dob.year == cur->dob.year) {
                gui_printf("Match DoB %d: %s", s->dob.year, s->name);
            }
            cur = cur->next;
        }
        s = s->next;
    }
}

void getInfoByDates2_v2(TList *s, TList *DoD) {
    while (s) {
        TList *cur = DoD;
        while (cur) {
            if (s->dod.year == cur->dod.year) {
                gui_printf("Match DoD %d: %s", s->dod.year, s->name);
            }
            cur = cur->next;
        }
        s = s->next;
    }
}

TList* countPersonality(TList *s, Date *prt) {
    TList *res = NULL;
    while (s) {
        if (s->dob.year == prt->year || s->dod.year == prt->year) {
            addPersonality(&res, s->name, s->definition, s->dob, s->dod);
        }
        s = s->next;
    }
    return res;
}

TList* mergeNodes(TList *s, TList *a) {
    TList *merged = NULL;
    while (s || a) {
        if (s) {
            addPersonality(&merged, s->name, s->definition, s->dob, s->dod);
            s = s->next;
        }
        if (a) {
            addPersonality(&merged, a->name, a->definition, a->dob, a->dod);
            a = a->next;
        }
    }
    return merged;
}

TList* merge2Nodes(TList *s, TList *a) {
    TList *head = mergeNodes(s, a);
    if (!head) return NULL;
    TList *curr = head;
    while (curr->next) curr = curr->next;
    curr->next = head; // Make circular
    head->prev = curr;
    return head;
}

TList* addPersonality_v2(FILE *f, TList *s, TList *a, char *name, char *DoB, char *DoD) {
    Date dob = stringToDate(DoB), dod = stringToDate(DoD);
    addPersonality(&s, name, "New entry", dob, dod);
    if (f) fprintf(f, "%s=New entry:%d:%d\n", name, dob.year, dod.year);
    return s;
}

TList* addEvents(TList *b, char *nameEvente, char *date) {
    Date d = stringToDate(date);
    addPersonality(&b, nameEvente, "Event", d, d);
    return b;
}

TQueue* sName(TList *s) {
    TQueue *q = (TQueue*)malloc(sizeof(TQueue));
    initQueue(q);
    if (!s) return q;
    // Sort list by word count in name
    bool swapped; TList *p1, *lp = NULL;
    do {
        swapped = false; p1 = s;
        while (p1->next != lp) {
            if (countWords(p1->name) > countWords(p1->next->name)) {
                char tn[100], td[500]; Date d1, d2;
                strcpy(tn, p1->name); strcpy(td, p1->definition); d1=p1->dob; d2=p1->dod;
                strcpy(p1->name, p1->next->name); strcpy(p1->definition, p1->next->definition); p1->dob=p1->next->dob; p1->dod=p1->next->dod;
                strcpy(p1->next->name, tn); strcpy(p1->next->definition, td); p1->next->dob=d1; p1->next->dod=d2;
                swapped = true;
            }
            p1 = p1->next;
        }
        lp = p1;
    } while (swapped);
    
    while (s) {
        enqueue(q, s->name, s->definition, s->dob, s->dod);
        s = s->next;
    }
    return q;
}

TQueue* ageP(TList *a) {
    TQueue *q = (TQueue*)malloc(sizeof(TQueue));
    initQueue(q);
    if (!a) return q;
    // Sort by age
    bool swapped; TList *p1, *lp = NULL;
    do {
        swapped = false; p1 = a;
        while (p1->next != lp) {
            if (calculateAge(p1->dob, p1->dod) > calculateAge(p1->next->dob, p1->next->dod)) {
                char tn[100], td[500]; Date d1, d2;
                strcpy(tn, p1->name); strcpy(td, p1->definition); d1=p1->dob; d2=p1->dod;
                strcpy(p1->name, p1->next->name); strcpy(p1->definition, p1->next->definition); p1->dob=p1->next->dob; p1->dod=p1->next->dod;
                strcpy(p1->next->name, tn); strcpy(p1->next->definition, td); p1->next->dob=d1; p1->next->dod=d2;
                swapped = true;
            }
            p1 = p1->next;
        }
        lp = p1;
    } while (swapped);

    while (a) {
        enqueue(q, a->name, a->definition, a->dob, a->dod);
        a = a->next;
    }
    return q;
}


TQueue* toQueue(TList *merged) {
    TQueue *q = (TQueue*)malloc(sizeof(TQueue));
    initQueue(q);
    while (merged) {
        enqueue(q, merged->name, merged->definition, merged->dob, merged->dod);
        merged = merged->next;
    }
    return q;
}


TList* updatePersonality(FILE *f, TList *s, TList *a, char *name, char *definition, char *DoB, char *DoD) {
    TList *n = searchNode(s, name);
    if (n) {
        if (definition && definition[0]) strncpy(n->definition, definition, 499);
        if (DoB && DoB[0]) n->dob = stringToDate(DoB);
        if (DoD && DoD[0]) n->dod = stringToDate(DoD);
    }
    return s;
}

TList* similarPersonality(TList *s, char *word) {
    TList *res = NULL;
    while (s) {
        if (strstr(s->name, word) || strstr(s->definition, word)) 
            addPersonality(&res, s->name, s->definition, s->dob, s->dod);
        s = s->next;
    }
    return res;
}

TList* palindromeName(TList *s) {
    TList *res = NULL;
    while (s) {
        char n[100]; strcpy(n, s->name); int l = strlen(n), isP = 1;
        for (int i = 0; i < l/2; i++) if (tolower(n[i]) != tolower(n[l-1-i])) { isP = 0; break; }
        if (isP) addPersonality(&res, s->name, s->definition, s->dob, s->dod);
        s = s->next;
    }
    return res;
}

/* Stubs for other headers */
int queueSize(TQueue *q) { int c = 0; TQNode *cur = q->front; while (cur) { c++; cur = cur->next; } return c; }
bool isPalindrome(TList *head) {
    if (!head) {
        gui_printf("List is empty. An empty list is trivially a palindrome.");
        return true;
    }
    
    // Find the tail of the list
    TList *front = head;
    TList *back = head;
    while (back->next) {
        back = back->next;
    }
    
    bool flag = true;
    
    while (front != back && front->prev != back) {
        char fName[128], bName[128];
        int i;
        for (i = 0; front->name[i] && i < 127; i++) fName[i] = tolower((unsigned char)front->name[i]);
        fName[i] = '\0';
        for (i = 0; back->name[i] && i < 127; i++) bName[i] = tolower((unsigned char)back->name[i]);
        bName[i] = '\0';
        
        if (strcmp(fName, bName) != 0) {
            gui_printf("Not a palindrome! Mismatch: \"%s\" != \"%s\".", front->name, back->name);
            flag = false;
            break;
        }
        front = front->next;
        back = back->prev;
    }
    
    if (flag) {
        gui_printf("Success! The list is a palindrome!");
    }
    return flag;
}

TList* findMiddle(TList *head) {
    if (!head) {
        gui_printf("List is empty. Middle node is NULL.");
        return NULL;
    }
    TList *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    gui_printf("Middle Node found: \"%s\" (%02d/%02d/%d)", 
               slow->name, slow->dob.day, slow->dob.month, slow->dob.year);
    return slow;
}