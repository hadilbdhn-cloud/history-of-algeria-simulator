#include "../include/utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Date utility functions
Date createDate(int day, int month, int year) {
    Date d = {day, month, year};
    return d;
}

Date stringToDate(const char *dateStr) {
    Date d = {0, 0, 0};
    if (dateStr) {
        sscanf(dateStr, "%d/%d/%d", &d.day, &d.month, &d.year);
    }
    return d;
}

// Memory management functions
void cleanupList(TList **head) {
    if (!head) return;
    TList *cur = *head;
    while (cur) {
        TList *nxt = cur->next;
        free(cur);
        cur = nxt;
    }
    *head = NULL;
}

void cleanupStack(TStack **top) {
    if (!top) return;
    TStack *cur = *top;
    while (cur) {
        TStack *nxt = cur->next;
        free(cur);
        cur = nxt;
    }
    *top = NULL;
}

void cleanupQueue(TQueue *q) {
    if (!q) return;
    TQNode *cur = q->front;
    while (cur) {
        TQNode *nxt = cur->next;
        free(cur);
        cur = nxt;
    }
    q->front = q->rear = NULL;
}

void cleanupTree(TTree *root) {
    if (!root) return;
    cleanupTree(root->left);
    cleanupTree(root->right);
    free(root);
}

int countWords(const char *str) {
    if (!str) return 0;
    int count = 0, inWord = 0;
    while (*str) {
        if (*str == ' ' || *str == '\n' || *str == '\t') inWord = 0;
        else if (!inWord) { inWord = 1; count++; }
        str++;
    }
    return count;
}

int calculateAge(Date dob, Date dod) {
    if (dod.year > 0) return dod.year - dob.year;
    return 2026 - dob.year; // Assuming current year for living people
}