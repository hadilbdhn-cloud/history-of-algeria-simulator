#include "../include/gui.h"

int main() {
    ShowLandingPage();
    return 0;
}
