
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "../include/gui.h"
#include "../include/types.h"
#include "../include/linked_list.h"
#include "../include/stack.h"
#include "../include/bst.h"
#include "../include/gui.h"
#include "../include/recursion.h"
#include "../include/gui.h"
#include "../include/utils.h"

/* ── Palette shortcuts (same as gui.c) ── */
#define CY  (Color){  0,210,255,255}
#define GR  (Color){  0,255,160,255}
#define AM  (Color){255,200,  0,255}
#define RE  (Color){255, 60, 80,255}
#define M2  (Color){ 30,144,255,255}
#define M3  (Color){180, 50,255,255}
#define M4  (Color){255,165,  0,255}
#define M5  (Color){255, 70,100,255}
#define DM  (Color){ 80,110,140,255}
#define TX  (Color){200,220,240,255}

#define C_PANEL (Color){  7, 12, 22, 240}
#define C_TEXT  TX
#define C_CYAN  CY
#define C_GREEN GR

#define WH  WHITE

/* ── Global data ── */
static TList  *personalities   = NULL;
static TStack *personalityStack = NULL;
static TQueue  personalityQueue;
static TTree  *personalityTree  = NULL;

/* ── Screen state ── */
typedef enum {
    SCR_MAIN,
    SCR_M2, SCR_M3, SCR_M4, SCR_M5,
    SCR_EXPLORER
} Screen;

static Screen g_scr = SCR_MAIN;
static int g_m5_mode = 0;

/* ── Form helpers ── */
static int  g_op   = -1;
static bool g_formDone = false;

static void ask(int op, const char *title, int n, const char **labels){
    g_op = op; g_formDone = false;
    FormBegin(title, n, labels);
}

static void print_ok (const char *m){ gui_printf("OK:  %s", m); }
static void print_err(const char *m){ gui_printf("ERR: %s", m); }

static void preload(void){
    initQueue(&personalityQueue);
    Date d1=createDate(6,9,1808),d2=createDate(26,5,1883);
    addPersonality(&personalities,"Emir Abdelkader","Algerian leader against French colonisation",d1,d2);
    personalityTree=insertBST(personalityTree,"Emir Abdelkader","Algerian leader against French colonisation",d1,d2);
    enqueue(&personalityQueue,"Emir Abdelkader","Algerian leader against French colonisation",d1,d2);
    
    Date d3=createDate(25,11,1923),d4=createDate(9,3,1957);
    addPersonality(&personalities,"Ben M'hidi Larbi","FLN chief, key leader in the War of Independence",d3,d4);
    personalityTree=insertBST(personalityTree,"Ben M'hidi Larbi","FLN chief, key leader in the War of Independence",d3,d4);
    enqueue(&personalityQueue,"Ben M'hidi Larbi","FLN chief, key leader in the War of Independence",d3,d4);
    
    Date d5=createDate(1,1,1930),d6=createDate(17,10,1961);
    addPersonality(&personalities,"Ali la Pointe","FLN militant, Battle of Algiers",d5,d6);
    personalityTree=insertBST(personalityTree,"Ali la Pointe","FLN militant, Battle of Algiers",d5,d6);
    enqueue(&personalityQueue,"Ali la Pointe","FLN militant, Battle of Algiers",d5,d6);

    // More Heroes
    Date d7=createDate(1,1,1830),d8=createDate(1,1,1863);
    addPersonality(&personalities,"Lalla Fatma N'Soumer","Heroic leader of the resistance in Kabylie",d7,d8);
    personalityTree=insertBST(personalityTree,"Lalla Fatma N'Soumer","Heroic leader of the resistance in Kabylie",d7,d8);
    enqueue(&personalityQueue,"Lalla Fatma N'Soumer","Heroic leader of the resistance in Kabylie",d7,d8);

    Date d9=createDate(18,1,1938),d10=createDate(8,10,1957);
    addPersonality(&personalities,"Hassiba Ben Bouali","Militant during the Battle of Algiers",d9,d10);
    personalityTree=insertBST(personalityTree,"Hassiba Ben Bouali","Militant during the Battle of Algiers",d9,d10);
    enqueue(&personalityQueue,"Hassiba Ben Bouali","Militant during the Battle of Algiers",d9,d10);

    Date d11=createDate(1,1,1926),d12=createDate(19,6,1956);
    addPersonality(&personalities,"Ahmed Zabana","First revolutionary executed by guillotine",d11,d12);
    personalityTree=insertBST(personalityTree,"Ahmed Zabana","First revolutionary executed by guillotine",d11,d12);
    enqueue(&personalityQueue,"Ahmed Zabana","First revolutionary executed by guillotine",d11,d12);

    Date d13=createDate(5,2,1917),d14=createDate(27,3,1956);
    addPersonality(&personalities,"Mostefa Ben Boulaid","The Father of the Algerian Revolution",d13,d14);
    personalityTree=insertBST(personalityTree,"Mostefa Ben Boulaid","The Father of the Algerian Revolution",d13,d14);
    enqueue(&personalityQueue,"Mostefa Ben Boulaid","The Father of the Algerian Revolution",d13,d14);

    Date d15=createDate(1,1,1935),d16=createDate(1,1,2024);
    addPersonality(&personalities,"Djamila Bouhired","Iconic militant and symbol of the revolution",d15,d16);
    personalityTree=insertBST(personalityTree,"Djamila Bouhired","Iconic militant and symbol of the revolution",d15,d16);
    enqueue(&personalityQueue,"Djamila Bouhired","Iconic militant and symbol of the revolution",d15,d16);
}


/* ══════════════════════════════════════════════════════════
   EXECUTE OPERATION AFTER FORM
══════════════════════════════════════════════════════════ */
static void exec_op(int op){
    const char *a=FormGet(0),*b=FormGet(1),*c=FormGet(2),*d=FormGet(3);
    switch(op){
    /* ── Module 2 LL ── */
    case 100:{TList*n=createNode(a,b,stringToDate(c),stringToDate(d));insertBeginning(&personalities,n);displayPersonalities(personalities);print_ok("Inserted at beginning.");}break;
    case 101:{TList*n=createNode(a,b,stringToDate(c),stringToDate(d));insertEnd(&personalities,n);displayPersonalities(personalities);print_ok("Inserted at end.");}break;
    case 102: deleteNode(&personalities,(char*)a); displayPersonalities(personalities); print_ok("Deleted (if found)."); break;
    case 103:{TList*f=searchNode(personalities,(char*)a);if(f)gui_printf("Found: %s | %s",f->name,f->definition);else print_err("Not found.");}break;
    case 104: displayList(personalities); break;
    case 105: displayListReverse(personalities); break;
    case 106: gui_printf("Count: %d", countNodes(personalities)); break;
    case 107: trace_bubble_sort(personalities); displayPersonalities(personalities); print_ok("Sorted & simulation active."); break;
    case 108: trace_reverse_list(&personalities); displayPersonalities(personalities); print_ok("Reversed & simulation active."); break;
    case 109: trace_find_middle(personalities); findMiddle(personalities); print_ok("Simulation active."); break;
    case 110: trace_is_palindrome(personalities); isPalindrome(personalities); print_ok("Simulation active."); break;
    case 111: removeDuplicates(personalities); displayPersonalities(personalities); print_ok("Duplicates removed."); break;
    case 112: trace_rotate_list(&personalities, atoi(a)); displayPersonalities(personalities); print_ok("Rotated & simulation active."); break;
    /* ── Module 2 Hist ── */
    case 120: personalities=sortWord(personalities); displayPersonalities(personalities); print_ok("Sorted by name."); break;
    case 121: personalities=sortWord2(personalities); displayPersonalities(personalities); print_ok("Sorted by length."); break;
    case 122: personalities=sortPersonality(personalities); displayPersonalities(personalities); print_ok("Sorted by age."); break;
    case 123:{TList*p=palindromeName(personalities);if(p){displayPersonalities(p);cleanupList(&p);}else print_err("None.");}break;
    case 124:{TList*s=similarPersonality(personalities,(char*)a);if(s){displayPersonalities(s);cleanupList(&s);}else print_err("None.");}break;
    case 125: displayPersonalities(personalities); break;
    case 126:{TList*f=searchPersonality(personalities,(char*)a);if(f)gui_printf("Found: %s (%d-%d)",f->name,f->dob.year,f->dod.year);else print_err("Not found.");}break;
    case 127: personalities=updatePersonality(NULL,personalities,personalities,(char*)a,(char*)b,(char*)c,(char*)d); displayPersonalities(personalities); print_ok("Updated."); break;
    case 128: personalities=deletepersonality(NULL,personalities,personalities,(char*)a); displayPersonalities(personalities); print_ok("Deleted."); break;
    /* ── Module 2 Queue ── */
    case 130: enqueue(&personalityQueue,(char*)a,(char*)b,stringToDate(c),stringToDate(d)); displayQueue(&personalityQueue); print_ok("Enqueued."); break;
    case 131:{TQNode*n=dequeue(&personalityQueue);if(n){gui_printf("Dequeued: %s",n->name);free(n);displayQueue(&personalityQueue);}else print_err("Empty.");}break;
    case 132:{TQNode*n=peekQueue(&personalityQueue);if(n)gui_printf("Front: %s",n->name);else print_err("Empty.");}break;
    case 133: displayQueue(&personalityQueue); break;
    case 134: gui_printf("Queue size: %d", queueSize(&personalityQueue)); break;
    /* ── Module 3 Stack Core ── */
    case 200: trace_push_stack(&personalityStack,(char*)a,(char*)b,stringToDate(c),stringToDate(d)); displayStack(personalityStack); print_ok("Pushed & simulation active."); break;
    case 201: trace_pop_stack(&personalityStack); displayStack(personalityStack); break;
    case 202:{TStack*t=peek(personalityStack);if(t)gui_printf("Top: %s",t->name);else print_err("Empty.");}break;
    case 203: displayStack(personalityStack); break;
    case 204: gui_printf("Stack size: %d", stackSize(personalityStack)); break;
    case 205: trace_reverse_stack(&personalityStack); displayStack(personalityStack); print_ok("Reversed & simulation active."); break;
    case 206: sortStack(&personalityStack); displayStack(personalityStack); print_ok("Sorted."); break;
    case 207:{TStack*s=searchStack(personalityStack,(char*)a);if(s)gui_printf("Found: %s",s->name);else print_err("Not found.");}break;
    /* ── Module 3 Hist ── */
    case 210: personalityStack=toStack(personalities); displayStack(personalityStack); print_ok("List→Stack done."); break;
    case 211: getInfoPersonality(personalityStack,(char*)a); break;
    case 212: personalityStack=sortNameStack(personalityStack); displayStack(personalityStack); print_ok("Sorted by name."); break;
    case 213: personalityStack=deleteName(personalityStack,(char*)a); displayStack(personalityStack); print_ok("Deleted."); break;
    case 214: personalityStack=updateStack_v2(personalityStack,(char*)a,(char*)b,(char*)c,(char*)d); displayStack(personalityStack); print_ok("Updated."); break;
    case 215: personalityStack=definitionStack(personalityStack); displayStack(personalityStack); print_ok("Sorted by def length."); break;
    case 216: getSmallest(personalityStack); break;
    case 217: continuousSearch(personalityStack, (char*)a); break;
    case 218: gui_printf("Killed: %s", isPersonalityKilled((char*)a)?"Yes":"No"); break;
    case 219: personalityStack=recRevStack(personalityStack); displayStack(personalityStack); print_ok("Recursively reversed."); break;
    /* ── Module 4 BST Core ── */
    case 300: trace_insert_bst(&personalityTree,(char*)a,(char*)b,stringToDate(c),stringToDate(d)); inorderTraversal(personalityTree); print_ok("Inserted & simulation active."); break;
    case 301: trace_delete_bst(&personalityTree,(char*)a); inorderTraversal(personalityTree); print_ok("Deleted & simulation active."); break;
    case 302: trace_search_bst(personalityTree,(char*)a); break;
    case 303: inorderTraversal(personalityTree); break;
    case 304: preorderTraversal(personalityTree); break;
    case 305: postorderTraversal(personalityTree); break;
    case 306: levelOrderTraversal(personalityTree); break;
    case 307: gui_printf("Height: %d", treeHeight(personalityTree)); break;
    case 308: gui_printf("Nodes: %d", countBSTNodes(personalityTree)); break;
    case 309: gui_printf("Leaves: %d", countLeafNodes(personalityTree)); break;
    case 310:{TTree*m=findMin(personalityTree);if(m)gui_printf("Min: %s",m->name);else print_err("Empty.");}break;
    case 311:{TTree*m=findMax(personalityTree);if(m)gui_printf("Max: %s",m->name);else print_err("Empty.");}break;
    case 312: gui_printf("Balanced: %s", isBalanced(personalityTree)?"Yes":"No"); break;
    case 313: personalityTree=mirrorBST(personalityTree); inorderTraversal(personalityTree); print_ok("Mirrored."); break;
    case 314: printBST(personalityTree,0); break;
    /* ── Module 4 Hist ── */
    case 320: personalityTree=toTree(personalityStack); inorderTraversal(personalityTree); print_ok("Stack→BST done."); break;
    case 321: personalityTree=deleteNameBST(personalityTree,(char*)a); inorderTraversal(personalityTree); print_ok("Deleted."); break;
    case 322: personalityTree=updateNameBST(personalityTree,(char*)a,(char*)b,(char*)c,(char*)d); inorderTraversal(personalityTree); print_ok("Updated."); break;
    case 323:{TTree*lca=lowestCommonAncestor(personalityTree,(char*)a,(char*)b);if(lca)gui_printf("LCA: %s",lca->name);else print_err("Not found.");}break;
    case 324:{int lo=atoi(a),hi=atoi(b);gui_printf("Count [%d,%d]: %d",lo,hi,countNodesRange(personalityTree,lo,hi));}break;
    case 325: personalityTree=convertListToBST(personalities); inorderTraversal(personalityTree); print_ok("List→BST done."); break;
    /* ── Module 5 Strings ── */
    case 400:{char s[256];strncpy(s,a,255);gui_printf("Length: %d",stringLength(s));gui_printf("Reversed: ");reverseString(s);gui_printf("%s",s);}break;
    case 401: gui_printf("Count '%s': %d", a, countWords((char*)a)); break;
    case 402: gui_printf("Palindrome: %s", isPalindromeString((char*)a)?"Yes":"No"); break;
    case 403:{char s[256];strncpy(s,a,255);removeChar(s,b[0]);gui_printf("Result: %s",s);}break;
    case 404:{char s[256];strncpy(s,a,255);replaceChar(s,b[0],c[0]);gui_printf("Result: %s",s);}break;
    case 405: gui_printf("Permutations of '%s':", a); namePermutation((char*)a); break;
    case 406: gui_printf("Subsequences of '%s':", a); subseqName((char*)a); break;
    case 407: gui_printf("Palindrome word: %s", isPalindromeWord((char*)a)?"Yes":"No"); break;
    /* ── Module 5 Math ── */
    case 410: gui_printf("Factorial(%s) = %d", a, trace_factorial(atoi(a))); break;
    case 411: gui_printf("Fibonacci(%s) = %d", a, trace_fibonacci(atoi(a))); break;
    case 412: gui_printf("GCD(%s,%s) = %d", a,b, trace_gcd(atoi(a),atoi(b))); break;
    case 413: gui_printf("Power(%s^%s) = %d", a,b, trace_power(atoi(a),atoi(b))); break;
    case 414: gui_printf("SumDigits(%s) = %d", a, sumOfDigits(atoi(a))); break;
    case 415: gui_printf("Reversed: %d", reverseNumber(atoi(a))); break;
    case 416: gui_printf("Armstrong: %s", isArmstrong(atoi(a))?"Yes":"No"); break;
    case 417: gui_printf("Prime: %s", isPrime(atoi(a))?"Yes":"No"); break;
    case 418: gui_printf("Tower of Hanoi (%s disks):",a); trace_tower_of_hanoi(atoi(a),'A','C','B'); break;
    /* ── Module 5 DS Recursive ── */
    case 420: printListRecursive(personalities); break;
    case 421: gui_printf("List count: %d", countNodesRecursive(personalities)); break;
    case 422: trace_search_recursive_list(personalities, (char*)a); break;
    case 423: trace_reverse_list_recursive(&personalities); printListRecursive(personalities); print_ok("List reversed & simulation active."); break;
    case 424: printStackRecursive(personalityStack); break;
    case 425: gui_printf("Stack count: %d", countStackNodesRecursive(personalityStack)); break;
    case 426: trace_reverse_stack_recursive(&personalityStack); printStackRecursive(personalityStack); print_ok("Stack reversed & simulation active."); break;
    case 427: inorderRecursive(personalityTree); break;
    case 428: gui_printf("BST height: %d", trace_tree_height_recursive(personalityTree)); break;
    case 429: gui_printf("BST nodes: %d", countTreeNodesRecursive(personalityTree)); break;
    case 430: personalityTree=mirrorRecursive(personalityTree); inorderRecursive(personalityTree); print_ok("BST mirrored."); break;
    case 431: gui_printf("BST balanced: %s", trace_is_balanced_recursive(personalityTree)?"Yes":"No"); break;
    /* ── Display All Snapshot ── */
    case 999:
        gui_printf("=== LINKED LIST ==="); displayPersonalities(personalities);
        gui_printf("=== STACK ==="); displayPersonalitiesStack(personalityStack);
        gui_printf("=== BST INORDER ==="); inorderTraversal(personalityTree);
        break;
    default: gui_printf("ERR: Unknown operation %d", op); break;
    }
}

/* ══════════════════════════════════════════════════════════
   BUTTON GRID HELPER
══════════════════════════════════════════════════════════ */
typedef struct { const char *label; int op; const char *fi[4]; Color col; } Btn;

/* Layout: buttons in grid starting at (x,y), w/h each, cols wide */
static void DrawBtnGrid(const Btn *btns, int n, int x, int y,
                        int bw, int bh, int cols, float t,
                        int *triggered){
    for(int i=0;i<n;i++){
        int col=i%cols, row=i/cols;
        Rectangle r={x+col*(bw+6), y+row*(bh+6), bw, bh};
        if(GuiButton(r, btns[i].label, btns[i].col, t))
            *triggered = i;
    }
}

/* ══════════════════════════════════════════════════════════
   SCREENS
══════════════════════════════════════════════════════════ */

/* ── MAIN MENU ── */
void DrawMainMenu(float t) {
    DrawSidebar(t, 0);
    bool back = false;
    DrawHeader("ALGERIA DB — COMMAND CENTER", CY, &back, t);
    
    // Dashboard fills the upper half of the content area
    DrawDashboard(personalities, t);

    /* 4 module cards - Lower half */
    struct { const char *title, *desc; Color c; Screen s; } cards[] = {
        {"MODULE 2","Linked Lists & Queues",M2,SCR_M2},
        {"MODULE 3","Stacks",              M3,SCR_M3},
        {"MODULE 4","Binary Search Tree",  M4,SCR_M4},
        {"MODULE 5","Recursion",           M5,SCR_M5},
    };

    int w = GetScreenWidth();
    int h = GetScreenHeight();
    int sx = 220, sy = 330, cw = (w-500-20-sx)/2 - 10, ch = 120, gap = 15;
    
    for(int i=0;i<4;i++){
        int col=i%2, row=i/2;
        Rectangle r={(float)(sx+col*(cw+gap)), (float)(sy+row*(ch+gap)), (float)cw, (float)ch};
        
        bool hover = CheckCollisionPointRec(GetMousePosition(), r);
        Color accent = cards[i].c;
        
        if (hover && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            g_scr = cards[i].s;
        }
        
        DrawRectangleRec(r, Fade(C_PANEL, hover ? 0.95f : 0.80f));
        float glowIntensity = hover ? (0.8f + 0.2f * sinf(t * 8.0f)) : 0.4f;
        GlowRect(r, accent, glowIntensity, hover ? 2 : 1);
        DrawRectangleLinesEx(r, hover ? 2.0f : 1.2f, accent);
        Corners(r, accent, 12);
        
        int badgeX = r.x + cw - 70;
        int badgeY = r.y + 12;
        DrawRectangle(badgeX, badgeY, 58, 16, Fade(accent, 0.12f));
        DrawRectangleLines(badgeX, badgeY, 58, 16, Fade(accent, 0.4f));
        DrawText("READY", badgeX + 12, badgeY + 4, 9, accent);
        DrawCircle(badgeX + 6, badgeY + 8, 3, accent);
        
        int iconX = r.x + 40;
        int iconY = r.y + ch/2;
        
        if (i == 0) {
            DrawRectangleLines(iconX - 22, iconY - 14, 20, 28, accent);
            DrawRectangleLines(iconX + 6, iconY - 14, 20, 28, accent);
            DrawLineEx((Vector2){(float)(iconX - 2), (float)(iconY - 4)}, (Vector2){(float)(iconX + 6), (float)(iconY - 4)}, 2.0f, accent);
            DrawTriangle((Vector2){(float)(iconX + 6), (float)(iconY - 4)}, (Vector2){(float)(iconX + 1), (float)(iconY - 8)}, (Vector2){(float)(iconX + 1), (float)(iconY)}, accent);
            
            DrawLineEx((Vector2){(float)(iconX + 6), (float)(iconY + 4)}, (Vector2){(float)(iconX - 2), (float)(iconY + 4)}, 2.0f, accent);
            DrawTriangle((Vector2){(float)(iconX - 2), (float)(iconY + 4)}, (Vector2){(float)(iconX + 3), (float)(iconY + 8)}, (Vector2){(float)(iconX + 3), (float)(iconY)}, accent);
        } else if (i == 1) {
            DrawRectangleLines(iconX - 18, iconY - 22, 36, 44, Fade(accent, 0.3f));
            for (int k = 0; k < 4; k++) {
                Rectangle plate = {(float)(iconX - 14), (float)(iconY + 12 - k * 10), 28.0f, 6.0f};
                DrawRectangleRec(plate, Fade(accent, 0.2f + k * 0.2f));
                DrawRectangleLinesEx(plate, 1, accent);
            }
        } else if (i == 2) {
            DrawCircleLines(iconX, iconY - 18, 8, accent);
            DrawCircleLines(iconX - 18, iconY + 14, 8, accent);
            DrawCircleLines(iconX + 18, iconY + 14, 8, accent);
            DrawLineEx((Vector2){(float)iconX, (float)(iconY - 10)}, (Vector2){(float)(iconX - 18), (float)(iconY + 6)}, 2.0f, Fade(accent, 0.7f));
            DrawLineEx((Vector2){(float)iconX, (float)(iconY - 10)}, (Vector2){(float)(iconX + 18), (float)(iconY + 6)}, 2.0f, Fade(accent, 0.7f));
        } else {
            DrawCircleLines(iconX, iconY, 24, Fade(accent, 0.3f));
            DrawCircleLines(iconX, iconY, 18, Fade(accent, 0.5f));
            DrawCircleLines(iconX, iconY, 12, Fade(accent, 0.7f));
            DrawCircleLines(iconX, iconY, 6, accent);
            DrawLineEx((Vector2){(float)iconX, (float)iconY}, (Vector2){(float)(iconX + 24), (float)(iconY - 24)}, 2.0f, accent);
        }
        
        int textX = r.x + 85;
        DrawText(cards[i].title, textX, r.y + 20, 18, accent);
        DrawText(cards[i].desc, textX, r.y + 46, 12, C_TEXT);
        DrawText("Double click or click enter to command database.", textX, r.y + ch - 22, 10, Fade(C_TEXT, 0.4f));
    }

    /* Navigation buttons - Bottom */
    Rectangle eb={(float)sx, (float)(sy + 2*(ch+gap) + 10), (w-500-20-sx)/2.0f - 5, 44};
    Rectangle sb={(float)(sx + (w-500-20-sx)/2 + 5), (float)(sy + 2*(ch+gap) + 10), (w-500-20-sx)/2.0f - 5, 44};
    
    if(GuiButton(eb, "OPEN DATA EXPLORER", GR, t)) g_scr = SCR_EXPLORER;
    if(GuiButton(sb, "DISPLAY ALL SNAPSHOT", CY, t)) exec_op(999);

    /* Output panel - Anchored to right */
    DrawOutputPanel((Rectangle){(float)(w-500),48,500,(float)(h-48)},t);
}



/* ── MODULE 2 ── */
static const Btn M2_BTNS[]={
    {"Insert Begin",  100,{"Name","Definition","DoB(DD/MM/YYYY)","DoD(DD/MM/YYYY)"},M2},
    {"Insert End",    101,{"Name","Definition","DoB(DD/MM/YYYY)","DoD(DD/MM/YYYY)"},M2},
    {"Delete",        102,{"Name","","",""},M2},
    {"Search",        103,{"Name","","",""},M2},
    {"Display All",   104,{NULL},M2},
    {"Display Rev",   105,{NULL},M2},
    {"Count Nodes",   106,{NULL},M2},
    {"Sort Alpha",    107,{NULL},M2},
    {"Reverse List",  108,{NULL},M2},
    {"Find Middle",   109,{NULL},M2},
    {"Is Palindrome", 110,{NULL},M2},
    {"Remove Dups",   111,{NULL},M2},
    {"Rotate K",      112,{"K","","",""},M2},
    {"Sort by Name",  120,{NULL},M2},
    {"Sort by Len",   121,{NULL},M2},
    {"Sort by Age",   122,{NULL},M2},
    {"Palindr Names", 123,{NULL},M2},
    {"Similar",       124,{"Word","","",""},M2},
    {"Hist Display",  125,{NULL},M2},
    {"Hist Search",   126,{"Name","","",""},M2},
    {"Update Person", 127,{"Name","New Def","New DoB","New DoD"},M2},
    {"Delete Person", 128,{"Name","","",""},M2},
    {"Enqueue",       130,{"Name","Definition","DoB(DD/MM/YYYY)","DoD(DD/MM/YYYY)"},M2},
    {"Dequeue",       131,{NULL},M2},
    {"Peek Queue",    132,{NULL},M2},
    {"Display Queue", 133,{NULL},M2},
    {"Queue Size",    134,{NULL},M2},
};
#define N_M2 27

/* ── MODULE 3 ── */
static const Btn M3_BTNS[]={
    {"Push",          200,{"Name","Definition","DoB(DD/MM/YYYY)","DoD(DD/MM/YYYY)"},M3},
    {"Pop",           201,{NULL},M3},
    {"Peek Top",      202,{NULL},M3},
    {"Display Stack", 203,{NULL},M3},
    {"Stack Size",    204,{NULL},M3},
    {"Reverse",       205,{NULL},M3},
    {"Sort Stack",    206,{NULL},M3},
    {"Search",        207,{"Name","","",""},M3},
    {"List To Stack", 210,{NULL},M3},
    {"Get Info",      211,{"Name","","",""},M3},
    {"Sort Names",    212,{NULL},M3},
    {"Delete Name",   213,{"Name","","",""},M3},
    {"Update",        214,{"Name","New Def","New DoB","New DoD"},M3},
    {"Sort By Def",   215,{NULL},M3},
    {"Get Smallest",  216,{NULL},M3},
    {"Cont. Search",  217,{"Keyword","","",""},M3},
    {"Is Killed?",    218,{"Definition text","","",""},M3},
    {"Rec Reverse",   219,{NULL},M3},
};
#define N_M3 18

/* ── MODULE 4 ── */
static const Btn M4_BTNS[]={
    {"Insert BST",    300,{"Name","Definition","DoB(DD/MM/YYYY)","DoD(DD/MM/YYYY)"},M4},
    {"Delete BST",    301,{"Name","","",""},M4},
    {"Search BST",    302,{"Name","","",""},M4},
    {"Inorder",       303,{NULL},M4},
    {"Preorder",      304,{NULL},M4},
    {"Postorder",     305,{NULL},M4},
    {"Level Order",   306,{NULL},M4},
    {"Height",        307,{NULL},M4},
    {"Count Nodes",   308,{NULL},M4},
    {"Count Leaves",  309,{NULL},M4},
    {"Find Min",      310,{NULL},M4},
    {"Find Max",      311,{NULL},M4},
    {"Is Balanced",   312,{NULL},M4},
    {"Mirror",        313,{NULL},M4},
    {"Print BST",     314,{NULL},M4},
    {"Stack To BST",  320,{NULL},M4},
    {"Delete Name",   321,{"Name","","",""},M4},
    {"Update Name",   322,{"Name","New Def","New DoB","New DoD"},M4},
    {"LCA",           323,{"Name 1","Name 2","",""},M4},
    {"Count Range",   324,{"Start Year","End Year","",""},M4},
    {"List To BST",   325,{NULL},M4},
};
#define N_M4 21

/* ── MODULE 5 ── */
static const Btn M5_BTNS[]={
    {"Str Length",    400,{"String","","",""},M5},
    {"Word Count",    401,{"String","","",""},M5},
    {"Is Palindrome", 402,{"String","","",""},M5},
    {"Remove Char",   403,{"String","Char","",""},M5},
    {"Replace Char",  404,{"String","Old","New",""},M5},
    {"Permutations",  405,{"Word","","",""},M5},
    {"Subsequences",  406,{"Word","","",""},M5},
    {"Palin Word",    407,{"Word","","",""},M5},
    {"Factorial",     410,{"N","","",""},M5},
    {"Fibonacci",     411,{"N","","",""},M5},
    {"GCD",           412,{"A","B","",""},M5},
    {"Power",         413,{"Base","Exp","",""},M5},
    {"Sum Digits",    414,{"N","","",""},M5},
    {"Reverse Num",   415,{"N","","",""},M5},
    {"Is Armstrong",  416,{"N","","",""},M5},
    {"Is Prime",      417,{"N","","",""},M5},
    {"Hanoi",         418,{"Disks (max 8)","","",""},M5},
    {"Print List",    420,{NULL},M5},
    {"Count List",    421,{NULL},M5},
    {"Search List",   422,{"Name","","",""},M5},
    {"Reverse List",  423,{NULL},M5},
    {"Print Stack",   424,{NULL},M5},
    {"Count Stack",   425,{NULL},M5},
    {"Rev Stack",     426,{NULL},M5},
    {"BST Inorder",   427,{NULL},M5},
    {"BST Height",    428,{NULL},M5},
    {"BST Count",     429,{NULL},M5},
    {"Mirror BST",    430,{NULL},M5},
    {"BST Balanced",  431,{NULL},M5},
};
#define N_M5 29

static void DrawModuleScreen(const Btn *btns, int n, const char *title,
                              Color accent, int modId, float t){
    DrawSidebar(t, modId);
    bool back=false;
    DrawHeader(title, accent, &back, t);
    if(back){ g_scr=SCR_MAIN; return; }

    /* Button grid: 5 columns, 700px wide area */
    int bw=130,bh=40,cols=5,gx=208,gy=54;
    int triggered=-1;
    DrawBtnGrid(btns,n,gx,gy,bw,bh,cols,t,&triggered);


    if(triggered>=0){
        const Btn *btn=&btns[triggered];
        gui_printf("\n--- ACTION: %s ---", btn->label);
        
        // Track the data structure type based on the active button
        if (modId == 5) {
            if (btn->op >= 420 && btn->op <= 423) g_m5_mode = 0;
            else if (btn->op >= 424 && btn->op <= 426) g_m5_mode = 1;
            else if (btn->op >= 427 && btn->op <= 431) g_m5_mode = 2;
        }
        
        int nf=0;
        for(int i=0;i<4;i++) if(btn->fi[i]&&btn->fi[i][0]!='\0') nf++;
        if(nf==0) exec_op(btn->op);
        else ask(btn->op, btn->label, nf, btn->fi);
    }

    /* DATA VISUALIZERS & TACTICAL TRACE SYSTEM */
    DrawAlgorithmCompanion(modId);

    if (IsTraceActive()) {
        DrawTracePlayer(t);
    } else {
        if (modId == 2)      DrawListVisualizer(personalities, t);
        else if (modId == 3) DrawStackVisualizer(personalityStack, t);
        else if (modId == 4) DrawTreeVisualizer(personalityTree, t);
        else if (modId == 5) {
            if (g_m5_mode == 0)      DrawListVisualizer(personalities, t);
            else if (g_m5_mode == 1) DrawStackVisualizer(personalityStack, t);
            else if (g_m5_mode == 2) DrawTreeVisualizer(personalityTree, t);
        }
    }

    int w = GetScreenWidth();
    int h = GetScreenHeight();
    DrawOutputPanel((Rectangle){(float)(w-500),48.0f,500.0f,(float)(h-48)},t);
}

/* ══════════════════════════════════════════════════════════
   MAIN
══════════════════════════════════════════════════════════ */
int main(void){
    ShowLandingPage();
    InitGUI();
    SetWindowState(FLAG_WINDOW_MAXIMIZED | FLAG_WINDOW_RESIZABLE);
    preload();

    float t=0;
    while(!GUIShouldClose()){
        t+=GetFrameTime();
        BeginDrawing();
        DrawCyberBG(t); // CRITICAL: Clear screen with animated background every frame

        /* Draw current screen */
        switch(g_scr){
        case SCR_MAIN: DrawMainMenu(t); break;
        case SCR_M2:   DrawModuleScreen(M2_BTNS,N_M2,"MODULE 2 - LINKED LISTS & QUEUES",M2,2,t); break;
        case SCR_M3:   DrawModuleScreen(M3_BTNS,N_M3,"MODULE 3 - STACKS",M3,3,t); break;
        case SCR_M4:   DrawModuleScreen(M4_BTNS,N_M4,"MODULE 4 - BINARY SEARCH TREE",M4,4,t); break;
        case SCR_M5:   DrawModuleScreen(M5_BTNS,N_M5,"MODULE 5 - RECURSION",M5,5,t); break;
        case SCR_EXPLORER: {
            DrawSidebar(t, 0);
            bool back = false;
            DrawHeader("DATA EXPLORER - CENTRAL DATABASE", GR, &back, t);
            if(back) g_scr = SCR_MAIN;
            DrawDataExplorer(personalities, t);
            DrawOutputPanel((Rectangle){GetScreenWidth()-500,48,500,GetScreenHeight()-48}, t);
        } break;
        }


        /* Form overlay on top */
        if(FormActive()){
            if(FormDraw(t)){
                if(!FormCancelled()) exec_op(g_op);
                FormReset();
            }
        }

        EndDrawing();
    }

    cleanupList(&personalities);
    cleanupStack(&personalityStack);
    cleanupQueue(&personalityQueue);
    cleanupTree(personalityTree);
    CloseGUI();
    return 0;
}
